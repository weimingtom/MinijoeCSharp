using System;

namespace com.google.minijoe.samples.shell
{

	using CompilerException = com.google.minijoe.compiler.CompilerException;
	using Eval = com.google.minijoe.compiler.Eval;
	using JsObject = com.google.minijoe.sys.JsObject;

	public class MjShell
	{
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public static void main(String[] argv) throws java.io.IOException, com.google.minijoe.compiler.CompilerException
		  public static void Main(string[] argv)
		  {
			  JsObject global = Eval.createGlobal();
			  string expr = "print('hello')";
			  Console.WriteLine("" + Eval.eval(expr, global));
		  }
	}

}