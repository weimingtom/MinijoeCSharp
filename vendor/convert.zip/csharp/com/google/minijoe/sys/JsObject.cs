using System;
using System.Collections;
using System.Text;

// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.sys
{


	/// <summary>
	/// Root class for all objects that are accessible via the JavaScript 
	/// interpreter. 
	/// 
	/// Constants named ID_XXX are the identification codes for corresponding
	/// native members, used in set() and evalNative().
	/// 
	/// This class also implements the container classes for numbers, booleans
	/// and strings since the object constructor must be able to construct all
	/// those classes and the string methods need to be transferable to other 
	/// classes
	/// 
	/// @author Stefan Haustein
	/// </summary>
	public class JsObject
	{

	  /// <summary>
	  /// special function id for empty constructors, 
	  /// ignored in JsObject.evalNative()
	  /// </summary>
	  public const int ID_NOOP = -1;

	  // Object methods

	  protected internal const int ID_INIT_OBJECT = 1;
	  protected internal const int ID_TO_STRING = 2;
	  protected internal const int ID_VALUE_OF = 3;
	  protected internal const int ID_TO_LOCALE_STRING = 4;
	  protected internal const int ID_HAS_OWN_PROPERTY = 5;
	  protected internal const int ID_IS_PROTOTYPE_OF = 6;
	  protected internal const int ID_PROPERTY_IS_ENUMERABLE = 7;

	  // global functions  

	  internal const int ID_PARSE_INT = 10;
	  internal const int ID_PARSE_FLOAT = 11;
	  internal const int ID_IS_NAN = 12;
	  internal const int ID_IS_FINITE = 13;
	  internal const int ID_DECODE_URI = 14;
	  internal const int ID_DECODE_URI_COMPONENT = 15;
	  internal const int ID_ENCODE_URI = 16;
	  internal const int ID_ENCODE_URI_COMPONENT = 17;
	  internal const int ID_PRINT = 18;

	  // math functions

	  internal const int ID_ABS = 19;
	  internal const int ID_ACOS = 20;
	  internal const int ID_ASIN = 21;
	  internal const int ID_ATAN = 22;
	  internal const int ID_ATAN2 = 23;
	  internal const int ID_CEIL = 24;
	  internal const int ID_COS = 25;
	  internal const int ID_EXP = 26;
	  internal const int ID_FLOOR = 27;
	  internal const int ID_LOG = 28;
	  internal const int ID_MAX = 29;
	  internal const int ID_MIN = 30;
	  internal const int ID_POW = 31;
	  internal const int ID_RANDOM = 32;
	  internal const int ID_ROUND = 33;
	  internal const int ID_SIN = 34;
	  internal const int ID_SQRT = 35;
	  internal const int ID_TAN = 36;

	  // boolean / number

	  internal const int ID_INIT_BOOLEAN = 37;
	  internal const int ID_INIT_STRING = 38;

	  // string methods

	  internal const int ID_FROM_CHAR_CODE = 39;

	  internal const int ID_CHAR_AT = 40;
	  internal const int ID_CHAR_CODE_AT = 41;
	  internal const int ID_CONCAT = 42;
	  internal const int ID_INDEX_OF = 43;
	  internal const int ID_LAST_INDEX_OF = 44;
	  internal const int ID_LOCALE_COMPARE = 45;
	  internal const int ID_MATCH = 46;
	  internal const int ID_REPLACE = 47;
	  internal const int ID_SEARCH = 48;
	  internal const int ID_SLICE = 49;
	  internal const int ID_SPLIT = 50;
	  internal const int ID_SUBSTRING = 51;
	  internal const int ID_TO_LOWER_CASE = 52;
	  internal const int ID_TO_LOCALE_LOWER_CASE = 53;
	  internal const int ID_TO_UPPER_CASE = 54;
	  internal const int ID_TO_LOCALE_UPPER_CASE = 55;
	  internal const int ID_LENGTH = 56;
	  internal const int ID_LENGTH_SET = 57;

	  internal const int ID_INIT_NUMBER = 60;
	  internal const int ID_TO_FIXED = 61;
	  internal const int ID_TO_EXPONENTIAL = 62;
	  internal const int ID_TO_PRECISION = 63;

	  internal const int ID_PARSE = 64;
	  internal const int ID_UTC = 65;

	  // constructors

	  internal const int ID_INIT_ARRAY = 66;
	  internal const int ID_INIT_ERROR = 67;
	  internal const int ID_INIT_FUNCTION = 68;
	  internal const int ID_INIT_DATE = 69;

	  // math constants

	  internal const int ID_E = 70;
	  internal const int ID_E_SET = 71;
	  internal const int ID_LN10 = 72;
	  internal const int ID_LN10_SET = 73;
	  internal const int ID_LN2 = 74;
	  internal const int ID_LN2_SET = 75;
	  internal const int ID_LOG2E = 76;
	  internal const int ID_LOG2E_SET = 77;
	  internal const int ID_LOG10E = 78;
	  internal const int ID_LOG10E_SET = 79;
	  internal const int ID_PI = 80;
	  internal const int ID_PI_SET = 81;
	  internal const int ID_SQRT1_2 = 82;
	  internal const int ID_SQRT1_2_SET = 83;
	  internal const int ID_SQRT2 = 84;
	  internal const int ID_SQRT2_SET = 85;

	  public const int TYPE_UNDEFINED = 0;
	  public const int TYPE_NULL = 1;
	  public const int TYPE_OBJECT = 2;
	  public const int TYPE_BOOLEAN = 3;
	  public const int TYPE_NUMBER = 4;
	  public const int TYPE_STRING = 5;
	  public const int TYPE_FUNCTION = 6;

	  /// <summary>
	  /// Javascript type names as returned by the typeof operator. Note
	  /// that TYPE_NULL and TYPE_OBJECT are mapped to object both. 
	  /// </summary>
	  internal static readonly string[] TYPE_NAMES = new string[] {"undefined", "object", "object", "boolean", "number", "string", "function"};

	  /// <summary>
	  /// Placeholder for Javascript undefined (Java null) values in hashtables </summary>
	  private static readonly object UNDEFINED_PLACEHOLDER = new object();

	  /// <summary>
	  /// Prototype of all Javascript objects </summary>
	  public static readonly JsObject OBJECT_PROTOTYPE = new JsObject(null).addVar("toString", new JsFunction(ID_TO_STRING, 0)).addVar("valueOf", new JsFunction(ID_VALUE_OF, 0)).addVar("toLocaleString", new JsFunction(ID_TO_LOCALE_STRING, 0)).addVar("hasOwnProperty", new JsFunction(ID_HAS_OWN_PROPERTY, 1)).addVar("isPrototypeOf", new JsFunction(ID_IS_PROTOTYPE_OF, 1)).addVar("propertyIsEnumerable", new JsFunction(ID_PROPERTY_IS_ENUMERABLE, 1));

	  public static readonly JsObject BOOLEAN_PROTOTYPE = new JsObject(OBJECT_PROTOTYPE);

	  public static readonly JsObject NUMBER_PROTOTYPE = new JsObject(OBJECT_PROTOTYPE).addVar("toFixed", new JsFunction(ID_TO_FIXED, 1)).addVar("toExponential", new JsFunction(ID_TO_EXPONENTIAL, 1)).addVar("toPrecision", new JsFunction(ID_TO_PRECISION, 1));

	  public static readonly JsObject STRING_PROTOTYPE = new JsObject(OBJECT_PROTOTYPE).addVar("charAt", new JsFunction(ID_CHAR_AT, 1)).addVar("charCodeAt", new JsFunction(ID_CHAR_CODE_AT, 1)).addVar("concat", new JsFunction(ID_CONCAT, 1)).addVar("indexOf", new JsFunction(ID_INDEX_OF, 2)).addVar("lastIndexOf", new JsFunction(ID_LAST_INDEX_OF, 2)).addVar("localeCompare", new JsFunction(ID_LOCALE_COMPARE, 1)).addVar("replace", new JsFunction(ID_REPLACE, 2)).addVar("search", new JsFunction(ID_SEARCH, 1)).addVar("slice", new JsFunction(ID_SLICE, 2)).addVar("split", new JsFunction(ID_SPLIT, 2)).addVar("substring", new JsFunction(ID_SUBSTRING, 2)).addVar("toLowerCase", new JsFunction(ID_TO_LOWER_CASE, 0)).addVar("toLocaleLowerCase", new JsFunction(ID_TO_LOCALE_LOWER_CASE, 0)).addVar("toUpperCase", new JsFunction(ID_TO_UPPER_CASE, 0)).addVar("toLocaleUpperCase", new JsFunction(ID_TO_LOCALE_UPPER_CASE, 0)).addVar("length", new JsFunction(ID_LENGTH, -1));

	  public static readonly object[] NO_PARAM = new object[0];

	  /// <summary>
	  /// Prototype chain </summary>
	  protected internal JsObject __proto__;

	  /// <summary>
	  /// Hashtable holding the reverse mapping for native methods. </summary>
	  private Hashtable natives = new Hashtable(10);
	  /// <summary>
	  /// Hashtable holding the properties and values of this object. </summary>
	  private Hashtable data;
	  /// <summary>
	  /// Parent object in scope chain </summary>
	  protected internal JsObject scopeChain;

	  /// <summary>
	  /// Primitive object value, used for Number and String. </summary>
	  internal object value;

	  /// <summary>
	  /// Constructs a new Javascript object with the given prototype. 
	  /// </summary>
	  public JsObject(JsObject __proto__)
	  {
		this.__proto__ = __proto__;
	  }

	  /// <summary>
	  /// Return the raw value of a property, taking the prototype chain into account, but not the
	  /// scope chain or native getters or setters.
	  /// </summary>
	  public virtual object getRawInPrototypeChain(string key)
	  {
		object result;

		if (data != null)
		{
		  result = data[key];
		  if (result != null)
		  {
			return result == UNDEFINED_PLACEHOLDER ? null : result;
		  }
		}

		if (__proto__ != null)
		{
		  result = __proto__.getRawInPrototypeChain(key);
		  if (result != null)
		  {
			return result;
		  }
		}
		return null;
	  }

	  /// <summary>
	  /// Returns the given property, taking native getters into account.
	  /// </summary>
	  /// <param name="prop"> Name of the property </param>
	  /// <returns> stored value or null </returns>
	  public virtual object getObject(string prop)
	  {
		object v = getRawInPrototypeChain(prop);
		if (v is JsFunction)
		{
		  JsFunction nat = (JsFunction) v;
		  if (nat.ParameterCount == -1)
		  {
			JsArray stack = new JsArray();
			evalNative(nat.index, stack, 0, 0);
			return stack.getObject(0);
		  }
		}
		else if (v == null && scopeChain != null)
		{
		  v = scopeChain.getObject(prop);
		}

		return v;
	  }

	  /// <summary>
	  /// Returns the numeric value for the given key. If the actual value is not
	  /// numeric, it is converted automatically, using the ECMA 262 conversion 
	  /// rules.
	  /// </summary>
	  public double getNumber(string key)
	  {
		return JsSystem.toNumber(getObject(key));
	  }

	  /// <summary>
	  /// Returns the string value for the given key. If the actual value is not a 
	  /// string, it is converted automatically, using the ECMA 262 conversion 
	  /// rules.
	  /// </summary>
	  public string getString(string key)
	  {
		return JsSystem.ToString(getObject(key));
	  }

	  /// <summary>
	  /// Returns the value at array index i, casted to an integer (32 bit). 
	  /// </summary>
	  public int getInt(string key)
	  {
		return (int) getNumber(key);
	  }

	  /// <summary>
	  /// Set method called from the byte code interpreter, 
	  /// avoiding temporary stack creation. This method is
	  /// overwritten in JsArray. 
	  /// </summary>
	  public virtual void vmSetOperation(JsArray stack, int keyIndex, int valueIndex)
	  {
		string key = stack.getString(keyIndex);

	// TODO re-enable optimization 
	//    Object old = getRaw(key);
	//
	//    if (old instanceof JsFunction){
	//      JsFunction nat = (JsFunction) old;
	//      if (nat.getParameterCount() == -1){
	//        evalNative(nat.index + 1, stack, valueIndex, 0);
	//        return;
	//      }
	//    }

		setObject(key, stack.getObject(valueIndex));
	  }

	  /// <summary>
	  /// Get method called from the bytecode interpreter,  avoiding temporary stack 
	  /// creation. This method is overwritten in JsArray and JsArguments.
	  /// </summary>
	  public virtual void vmGetOperation(JsArray stack, int keyIndex, int valueIndex)
	  {
		string key = stack.getString(keyIndex);

	 // TODO re-enable optimization 
	//    Object old = getRaw(key);
	//
	//    if (old instanceof JsFunction){
	//      JsFunction f = (JsFunction) old;
	//      if (f.getParameterCount() == -1){
	//        evalNative(f.index, stack, valueIndex, 0);
	//        return;
	//      }
	//    }
		stack.setObject(valueIndex, getObject(key));
	  }

	  /// <summary>
	  /// Set the given property to the given value without taking the scope or
	  /// prototype chain into account.
	  /// </summary>
	  /// <param name="prop"> property name </param>
	  /// <param name="value"> value to set </param>
	  /// <returns> this (for chained calls) </returns>
	  public virtual JsObject addVar(string prop, object v)
	  {
		if (data == null)
		{
		  data = new Hashtable();
		}
		data[prop] = v == null ? UNDEFINED_PLACEHOLDER : v;
		if (v is JsFunction && ((JsFunction) v).index != ID_NOOP)
		{
		  string key = getNativeKey(((JsFunction) v).factoryTypeId, ((JsFunction) v).index);
		  if (key != null)
		  {
			if (natives.ContainsKey(key))
			{
			  Console.WriteLine("Duplicate native function ID '" + ((JsFunction) v).index + "' detected for method '" + prop + "'.");
			}
			else
			{
			  natives[key] = prop;
			}
		  }
		}
		return this;
	  }

	  /// <summary>
	  /// Convenience method for <tt>addVar(prop, new JsFunction(int nativeCallId, int parCount)</tt>
	  /// </summary>
	  public virtual JsObject addNative(string prop, int nativePropertyId, int parCount)
	  {
		return addVar(prop, new JsFunction(nativePropertyId, parCount));
	  }

	  /// <summary>
	  /// Get the function's name for a particular ID.
	  /// </summary>
	  public virtual string getFunctionName(int factoryTypeId, int index)
	  {
		return getFunctionNameImpl(getNativeKey(factoryTypeId, index));
	  }

	  private string getFunctionNameImpl(string key)
	  {
		string prop = (string) natives[key];
		if (prop == null && __proto__ != null)
		{
		  prop = __proto__.getFunctionNameImpl(key);
		}
		return prop;
	  }

	  private string getNativeKey(int factoryTypeId, int index)
	  {
		return (factoryTypeId <= JsSystem.FACTORY_ID_OBJECT) ? JsSystem.FACTORY_ID_OBJECT + ":" + index : factoryTypeId + ":" + index;
	  }

	  /// <summary>
	  /// Set the given property to a numeric value.
	  /// </summary>
	  public virtual void setNumber(string key, double n)
	  {
		setObject(key, new double?(n));
	  }

	  /// <summary>
	  /// Sets the given property to the given value, taking the prototype chain,
	  /// scope chain, and setters into account.
	  /// </summary>
	  /// <param name="prop"> property name </param>
	  /// <param name="value"> value to set </param>
	  /// <returns> this (for chained calls) </returns>
	  public virtual void setObject(string key, object v)
	  {

		object old = getRawInPrototypeChain(key);
		if (old is JsFunction && ((JsFunction) old).ParameterCount == -1)
		{
			JsFunction nat = (JsFunction) old;
			JsArray stack = new JsArray();
			stack.setObject(0, v);
			evalNative(nat.index + 1, stack, 0, 0);
			return;
		}
		else if (old == null && scopeChain != null)
		{
		  scopeChain.setObject(key, v);
		}
		else
		{
		  if (data == null)
		  {
			data = new Hashtable();
		  }
		  data[key] = v == null ? UNDEFINED_PLACEHOLDER : v;
		}
	  }

	  /// <summary>
	  /// Returns a key enumeration for this object only, not including the 
	  /// prototype or scope chain.
	  /// </summary>
	  public virtual System.Collections.IEnumerator keys()
	  {
		if (data == null)
		{
		  data = new Hashtable();
		}
		return data.Keys.GetEnumerator();
	  }

	  /// <summary>
	  /// Returns elements enumeration for this object only, not including the
	  /// prototype or scope chain.
	  /// </summary>
	  public virtual System.Collections.IEnumerator elements()
	  {
		if (data == null)
		{
		  data = new Hashtable();
		}
		return data.Values.GetEnumerator();
	  }

	  /// <summary>
	  /// Returns a string representation of this.
	  /// </summary>
	  public override string ToString()
	  {
		return value == null ? "[object Object]" : value.ToString();
	  }

	  /// <summary>
	  /// Delete the given property. Returns true if it was actually deleted.
	  /// </summary>
	  public virtual bool delete(string key)
	  {
		if (data == null)
		{
		  return true;
		}

		//TODO check whether this covers dontdelete sufficiently

		object old = data[key];
		bool isFunc = old is JsFunction;
		if (isFunc && ((JsFunction) old).ParameterCount == -1)
		{
		  return false;
		}

		data.Remove(key);
		if (isFunc)
		{
			natives.Remove(getNativeKey(((JsFunction) old).factoryTypeId, ((JsFunction) old).index));
		}
		return true;
	  }

	  /// <summary>
	  /// Clears all properties.
	  /// </summary>
	  public virtual void clear()
	  {
		if (data != null)
		{
		  data.Clear();
		  data = null;
		}
	  }

	  /// <summary>
	  /// Execute java member implementation. Parameters for functions start at 
	  /// stack[sp+2]. Function and getter results are returned at stack[sp+0].
	  /// The assignement value for a setter is stored at stack[sp+0]. 
	  /// </summary>
	  public virtual void evalNative(int index, JsArray stack, int sp, int parCount)
	  {
		object obj;
		switch (index)
		{
		  // object methods

		  case ID_NOOP:
			break;

		  case ID_INIT_OBJECT:
			obj = stack.getObject(sp + 2);
			if (isConstruction(stack, sp))
			{
			  if (obj is bool? || obj is double? || obj is string)
			  {
				value = obj;
			  }
			  else if (obj is JsObject)
			  {
				stack.setObject(sp - 1, obj);
			  }
			  // otherwise, don't do anything -- regular constructor call
			}
			else
			{
			  if (obj == null || obj == JsSystem.JS_NULL)
			  {
				stack.setObject(sp, new JsObject(OBJECT_PROTOTYPE));
			  }
			  else
			  {
				stack.setObject(sp, JsSystem.toJsObject(obj));
			  }
			}
			break;

		  case ID_TO_STRING:
		  case ID_TO_LOCALE_STRING:
			stack.setObject(sp, JsSystem.ToString(stack.getObject(sp)));
			break;

		  case ID_HAS_OWN_PROPERTY:
			stack.setBoolean(sp, data != null && data[stack.getString(sp + 2)] != null);
			break;

		  case ID_IS_PROTOTYPE_OF:
			obj = stack.getObject(sp + 2);
			stack.setBoolean(sp, false);
			while (obj is JsObject)
			{
			  if (obj == this)
			  {
				stack.setBoolean(sp, true);
				break;
			  }
			}
			break;

		  case ID_PROPERTY_IS_ENUMERABLE:
			obj = getRawInPrototypeChain(stack.getString(sp + 2));
			stack.setBoolean(sp, obj != null && !(obj is JsFunction));
			break;

		  case ID_VALUE_OF:
			stack.setObject(sp, value == null ? this : value);
			break;

			// Number methods

		  case ID_INIT_NUMBER:
			if (isConstruction(stack, sp))
			{
			  value = new double?(stack.getNumber(sp + 2));
			}
			else
			{
			  stack.setNumber(sp, stack.getNumber(sp + 2));
			}
			break;

			// Boolean methods

		  case ID_INIT_BOOLEAN:
			if (isConstruction(stack, sp))
			{
			  value = stack.getBoolean(sp + 2) ? true : false;
			}
			else
			{
			  stack.setObject(sp, stack.getBoolean(sp + 2) ? true : false);
			}
			break;

		  case ID_INIT_STRING:
			if (isConstruction(stack, sp))
			{
			  value = stack.getString(sp + 2);
			}
			else
			{
			  stack.setObject(sp, parCount == 0 ? "" : stack.getString(sp + 2));
			}
			break;

		  // initializers that can be used as functions need to be covered in Object

		  case ID_INIT_ARRAY:
			JsArray array = (isConstruction(stack, sp) ? (JsArray) this : new JsArray());
			if (parCount == 1 && stack.isNumber(sp + 2))
			{
			  array.Size = stack.getInt(sp + 2);
			}
			else
			{
			  for (int i = 0; i < parCount; i++)
			  {
				stack.copy(sp + i + 2, array, i);
			  }
			}
			stack.setObject(sp, array);
			break;

		  case ID_INIT_ERROR:
			if (isConstruction(stack, sp))
			{
			  setObject("message", stack.getString(sp + 2));
			}
			else
			{
			  stack.setObject(sp, new JsError(stack.getJsObject(sp), stack.getString(sp + 2)));
			}
			break;


		  case ID_INIT_FUNCTION:
			// Note: this will exchange the "this" object at sp-1 if it is used as constructor
			bool construction = isConstruction(stack, sp);

			StringBuilder buf = new StringBuilder("(function(");
			for (int i = 0; i < parCount - 1; i++)
			{
			  if (i != 0)
			  {
				buf.Append(',');
			  }
			  buf.Append(stack.getString(sp + 2 + i));
			}
			buf.Append("){");
			if (parCount != 0)
			{
			  buf.Append(stack.getString(sp + 2 + parCount - 1));
			}
			buf.Append("});");

			Console.WriteLine("eval: " + buf);

			JsObject global = (JsObject) stack.getObject(0);
			JsFunction eval = (JsFunction) global.getObject("eval");
			stack.setObject(sp, global); // global
			stack.setObject(sp + 1, eval);
			stack.setObject(sp + 2, buf.ToString());
			eval.eval(stack, sp, 1);

			if (construction)
			{
			  stack.copy(sp, stack, sp - 1);
			}
			break;


		  case ID_INIT_DATE:
			// reset to defaults
			if (isConstruction(stack, sp))
			{
			  JsDate d = (JsDate) this;
			  if (parCount == 1)
			  {
				d.time = new DateTime(new DateTime((long) stack.getNumber(sp + 2)));
			  }
			  else if (parCount > 1)
			  {
				d.time = new DateTime(new DateTime());
				int year = stack.getInt(sp + 2);
				if (year >= 0 && year <= 99)
				{
				  year += 1900;
				}
				d.setDate(false, year, stack.getNumber(sp + 3), stack.getNumber(sp + 4));

				d.setTime(false, stack.getNumber(sp + 5), stack.getNumber(sp + 6), stack.getNumber(sp + 7), stack.getNumber(sp + 8));
			  }
			}
			else
			{
			  stack.setObject(sp, (new JsDate(JsDate.DATE_PROTOTYPE)).ToString(true, true, true));
			}
			break;


		  // global properties

		  case ID_PRINT:
			Console.WriteLine(stack.getString(sp + 2));
			break;

		  case ID_PARSE_INT:
			string s = stack.getString(sp + 2).Trim().ToLower();
			try
			{
			  if (stack.isNull(sp + 3))
			  {
				stack.setInt(sp, s.StartsWith("0x") ? Convert.ToInt32(s.Substring(2), 16) : Convert.ToInt32(s));
			  }
			  else
			  {
				stack.setInt(sp, Convert.ToInt32(s, stack.getInt(sp + 3)));
			  }
			}
			catch (NumberFormatException)
			{
			  stack.setInt(sp, 0);
			}
			break;

		  case ID_PARSE_FLOAT:
			try
			{
			  stack.setNumber(sp, Convert.ToDouble(stack.getString(sp + 2)));
			}
			catch (NumberFormatException)
			{
			  stack.setNumber(sp, double.NaN);
			}
			break;

		  case ID_IS_NAN:
			stack.setBoolean(sp, double.IsNaN(stack.getNumber(sp + 2)));
			break;

		  case ID_IS_FINITE:
			double d = stack.getNumber(sp + 2);
			stack.setBoolean(sp, !double.IsInfinity(d) && !double.IsNaN(d));
			break;

		  case ID_DECODE_URI:
			obj = stack.getObject(sp + 2);
			if (obj is sbyte[])
			{
			  stack.setObject(sp, JsSystem.decodeURI((sbyte[]) obj));
			}
			else
			{
			  stack.setObject(sp, JsSystem.decodeURI(obj.ToString()));
			}
			break;

		  case ID_ENCODE_URI:
			obj = stack.getObject(sp + 2);
			if (obj is sbyte[])
			{
			  stack.setObject(sp, JsSystem.encodeURI((sbyte[]) obj));
			}
			else
			{
			  stack.setObject(sp, JsSystem.encodeURI(obj.ToString()));
			}
			break;

		  //TODO Implement
		  case ID_DECODE_URI_COMPONENT:
		  case ID_ENCODE_URI_COMPONENT:
			throw new Exception("NYI");

		  // math properties

		  case ID_ABS:
			stack.setNumber(sp, Math.Abs(stack.getNumber(sp + 2)));
			break;

		  case ID_ACOS:
		  case ID_ASIN:
		  case ID_ATAN:
		  case ID_ATAN2:
			throw new Exception("NYI");

		  case ID_CEIL:
			stack.setNumber(sp, Math.Ceiling(stack.getNumber(sp + 2)));
			break;

		  case ID_COS:
			stack.setNumber(sp, Math.Cos(stack.getNumber(sp + 2)));
			break;

		  case ID_EXP:
			stack.setNumber(sp, JsSystem.exp(stack.getNumber(sp + 2)));
			break;

		  case ID_FLOOR:
			stack.setNumber(sp, Math.Floor(stack.getNumber(sp + 2)));
			break;

		  case ID_LOG:
			stack.setNumber(sp, JsSystem.ln(stack.getNumber(sp + 2)));
			break;

		  case ID_MAX:
			d = double.NegativeInfinity;
			for (int i = 0; i < parCount; i++)
			{
			  d = Math.Max(d, stack.getNumber(sp + 2 + i));
			}
			stack.setNumber(sp, d);
			break;

		  case ID_MIN:
			d = double.PositiveInfinity;
			for (int i = 0; i < parCount; i++)
			{
			  d = Math.Min(d, stack.getNumber(sp + 2 + i));
			}
			stack.setNumber(sp, d);
			break;

		  case ID_POW:
			stack.setNumber(sp, JsSystem.pow(stack.getNumber(sp + 2), stack.getNumber(sp + 3)));
			break;

		  case ID_RANDOM:
			stack.setNumber(sp, JsSystem.random.NextDouble());
			break;

		  case ID_ROUND:
			stack.setNumber(sp, Math.Floor(stack.getNumber(sp + 2) + 0.5));
			break;

		  case ID_SIN:
			stack.setNumber(sp, Math.Sin(stack.getNumber(sp + 2)));
			break;

		  case ID_SQRT:
			stack.setNumber(sp, Math.Sqrt(stack.getNumber(sp + 2)));
			break;

		  case ID_TAN:
			stack.setNumber(sp, Math.Tan(stack.getNumber(sp + 2)));
			break;

		  // string methods

		  case ID_FROM_CHAR_CODE:
			char[] chars = new char[parCount];
			for (int i = 0; i < parCount; i++)
			{
			  chars[i] = (char) stack.getInt(sp + 2 + i);
			}
			stack.setObject(sp, new string(chars));
			break;

		  // string.prototype methods

		  case ID_CHAR_AT:
			s = stack.getString(sp);
			int i = stack.getInt(sp + 2);
			stack.setObject(sp, i < 0 || i >= s.Length ? "" : s.Substring(i, 1));
			break;

		  case ID_CHAR_CODE_AT:
			s = stack.getString(sp);
			i = stack.getInt(sp + 2);
			stack.setNumber(sp, i < 0 || i >= s.Length ? double.NaN : s[i]);
			break;

		  case ID_CONCAT:
			buf = new StringBuilder(stack.getString(sp));
			for (i = 0; i < parCount; i++)
			{
			  buf.Append(stack.getString(sp + i + 2));
			}
			stack.setObject(sp, buf.ToString());
			break;

		  case ID_INDEX_OF:
			stack.setNumber(sp, stack.getString(sp).IndexOf(stack.getString(sp + 2), stack.getInt(sp + 3)));
			break;

		  case ID_LAST_INDEX_OF:
			s = stack.getString(sp);
			string find = stack.getString(sp + 2);
			d = stack.getNumber(sp + 3);
			int max = (double.IsNaN(d)) ? s.Length : (int) d;

			int best = -1;
			while (true)
			{
			  int found = s.IndexOf(find, best + 1);
			  if (found == -1 || found > max)
			  {
				break;
			  }
			  best = found;
			}

			stack.setNumber(sp, best);
			break;

		  case ID_LOCALE_COMPARE:
			stack.setNumber(sp, stack.getString(sp).CompareTo(stack.getString(sp + 2)));
			break;

		  case ID_REPLACE:
			s = stack.getString(sp);
			find = stack.getString(sp + 2);
			string replace = stack.getString(sp + 3);
			if (!find.Equals(""))
			{
			  StringBuilder sb = new StringBuilder(s);
			  int length = find.Length;

			  // Parse nodes into vector
			  while ((index = sb.ToString().IndexOf(find)) >= 0)
			  {
				sb.Remove(index, index + length);
				sb.Insert(index, replace);
			  }
			  stack.setObject(sp, sb.ToString());
			  sb = null;
			}
			break;
		  case ID_MATCH:
		  case ID_SEARCH:
			throw new Exception("Regexp NYI");

		  case ID_SLICE:
			s = stack.getString(sp);
			int len = s.Length;
			int start = stack.getInt(sp + 2);
			int end = stack.isNull(sp + 3) ? len : stack.getInt(sp + 3);
			if (start < 0)
			{
			  start = Math.Max(len + start, 0);
			}
			if (end < 0)
			{
			  end = Math.Max(len + start, 0);
			}
			if (start > len)
			{
			  start = len;
			}
			if (end > len)
			{
			  end = len;
			}
			if (end < start)
			{
			  end = start;
			}
			stack.setObject(sp, s.Substring(start, end - start));
			break;

		  case ID_SPLIT:
			s = stack.getString(sp);
			string sep = stack.getString(sp + 2);
			double limit = stack.getNumber(sp + 3);
			if (double.IsNaN(limit) || limit < 1)
			{
			  limit = double.MaxValue;
			}

			JsArray a = new JsArray();
			if (sep.Length == 0)
			{
			  if (s.Length < limit)
			  {
				limit = s.Length;
			  }
			  for (i = 0; i < limit; i++)
			  {
				a.setObject(i, s.Substring(i, 1));
			  }
			}
			else
			{
			  int cut0 = 0;
			  while (cut0 < s.Length && a.size() < limit)
			  {
				int cut = s.IndexOf(sep, cut0);
				if (cut == -1)
				{
				  cut = s.Length;
				}
				a.setObject(a.size(), s.Substring(cut0, cut - cut0));
				cut0 = cut + sep.Length;
			  }
			}
			stack.setObject(sp, a);
			break;

		  case ID_SUBSTRING:
			s = stack.getString(sp);
			len = s.Length;
			start = stack.getInt(sp + 2);
			end = stack.isNull(sp + 3) ? len : stack.getInt(sp + 3);
			if (start > end)
			{
			  int tmp = end;
			  end = start;
			  start = tmp;
			}
			start = Math.Min(Math.Max(0, start), len);
			end = Math.Min(Math.Max(0, end), len);
			stack.setObject(sp, s.Substring(start, end - start));
			break;

		  case ID_TO_LOWER_CASE: //TODO: which locale to use as defautlt? us?
		  case ID_TO_LOCALE_LOWER_CASE:
			stack.setObject(sp, stack.getString(sp + 2).ToLower());
			break;

		  case ID_TO_UPPER_CASE: //TODO: which locale to use as defautlt? us?
		  case ID_TO_LOCALE_UPPER_CASE:
			stack.setObject(sp, stack.getString(sp + 2).ToUpper());
			break;

		  case ID_LENGTH:
			stack.setInt(sp, ToString().Length);
			break;

		  case ID_LENGTH_SET:
			// cannot be changed!
			break;

		  case ID_TO_EXPONENTIAL:
		  case ID_TO_FIXED:
		  case ID_TO_PRECISION:
			stack.setObject(sp, JsSystem.formatNumber(index, stack.getNumber(sp + 2), stack.getNumber(sp + 3)));
			break;

		  case ID_UTC:
			JsDate date = new JsDate(JsDate.DATE_PROTOTYPE);
			date.time = new DateTime(new DateTime());
			int year = stack.getInt(sp + 2);
			if (year >= 0 && year <= 99)
			{
			  year += 1900;
			}
			date.setDate(true, year, stack.getNumber(sp + 3), stack.getNumber(sp + 4));

			date.setTime(true, stack.getNumber(sp + 5), stack.getNumber(sp + 6), stack.getNumber(sp + 7), stack.getNumber(sp + 8));

			stack.setNumber(sp, date.time.Ticks.Time);
			break;

		  case ID_PARSE:
			double[] vals = new double[] {double.NaN, double.NaN, double.NaN, double.NaN, double.NaN, double.NaN, double.NaN};

			s = stack.getString(sp + 2);
			int curr = -1;
			int pos = 0;
			for (i = 0; i < s.Length; i++)
			{
			  char c = s[i];
			  if (c >= '0' && c <= '9')
			  {
				if (curr == -1)
				{
				  curr = c - 48;
				}
				else
				{
				  curr = curr * 10 + (c - 48);
				}
			  }
			  else if (curr != -1)
			  {
				if (pos < vals.Length)
				{
				  vals[pos++] = curr;
				}
				curr = -1;
			  }
			}
			if (curr != -1 && pos < vals.Length)
			{
			  vals[pos++] = curr;
			}

			bool utc = s.EndsWith("GMT") || s.EndsWith("UTC");
			date = new JsDate(JsDate.DATE_PROTOTYPE);
			date.time = new DateTime(new DateTime());
			date.setDate(utc, vals[0], vals[1], vals[2]);
			date.setTime(utc, vals[3], vals[4], vals[5], vals[6]);
			stack.setNumber(sp, date.time.Ticks.Time);
			break;

		  // Math constants

		  case ID_E:
			stack.setNumber(sp, Math.E);
			break;
		  case ID_LN10:
			stack.setNumber(sp, 2.302585092994046);
			break;
		  case ID_LN2:
			stack.setNumber(sp, JsSystem.LN2);
			break;
		  case ID_LOG2E:
			stack.setNumber(sp, 1.4426950408889634);
			break;
		  case ID_LOG10E:
			stack.setNumber(sp, 0.4342944819032518);
			break;
		  case ID_PI:
			stack.setNumber(sp, Math.PI);
			break;
		  case ID_SQRT1_2:
			stack.setNumber(sp, Math.Sqrt(0.5));
			break;
		  case ID_SQRT2:
			stack.setNumber(sp, Math.Sqrt(2.0));
			break;

		  case ID_E_SET:
		  case ID_LN10_SET:
		  case ID_LN2_SET:
		  case ID_LOG2E_SET:
		  case ID_LOG10E_SET:
		  case ID_PI_SET:
		  case ID_SQRT1_2_SET:
		  case ID_SQRT2_SET:
			// dont do anything: cannot overwrite those values!
			break;

		  default:
			throw new System.ArgumentException("Unknown native id: " + index + " this: " + this);
		}
	  }

	  /// <summary>
	  /// Determines whether the given call is an actual constructor call 
	  /// (with new)
	  /// TODO check whether there may be false positives...
	  /// </summary>
	  protected internal virtual bool isConstruction(JsArray stack, int sp)
	  {
		return sp > 0 && stack.getObject(sp - 1) == stack.getObject(sp);
	  }
	}

}