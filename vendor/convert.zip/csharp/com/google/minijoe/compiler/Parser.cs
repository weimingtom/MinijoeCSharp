using System;
using System.Collections;

// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler
{

	using ArrayLiteral = com.google.minijoe.compiler.ast.ArrayLiteral;
	using AssignmentExpression = com.google.minijoe.compiler.ast.AssignmentExpression;
	using AssignmentOperatorExpression = com.google.minijoe.compiler.ast.AssignmentOperatorExpression;
	using BinaryOperatorExpression = com.google.minijoe.compiler.ast.BinaryOperatorExpression;
	using BlockStatement = com.google.minijoe.compiler.ast.BlockStatement;
	using BooleanLiteral = com.google.minijoe.compiler.ast.BooleanLiteral;
	using BreakStatement = com.google.minijoe.compiler.ast.BreakStatement;
	using CallExpression = com.google.minijoe.compiler.ast.CallExpression;
	using CaseStatement = com.google.minijoe.compiler.ast.CaseStatement;
	using ConditionalExpression = com.google.minijoe.compiler.ast.ConditionalExpression;
	using ContinueStatement = com.google.minijoe.compiler.ast.ContinueStatement;
	using DeleteExpression = com.google.minijoe.compiler.ast.DeleteExpression;
	using DoStatement = com.google.minijoe.compiler.ast.DoStatement;
	using EmptyStatement = com.google.minijoe.compiler.ast.EmptyStatement;
	using Expression = com.google.minijoe.compiler.ast.Expression;
	using ExpressionStatement = com.google.minijoe.compiler.ast.ExpressionStatement;
	using ForInStatement = com.google.minijoe.compiler.ast.ForInStatement;
	using ForStatement = com.google.minijoe.compiler.ast.ForStatement;
	using FunctionDeclaration = com.google.minijoe.compiler.ast.FunctionDeclaration;
	using FunctionLiteral = com.google.minijoe.compiler.ast.FunctionLiteral;
	using Identifier = com.google.minijoe.compiler.ast.Identifier;
	using IfStatement = com.google.minijoe.compiler.ast.IfStatement;
	using IncrementExpression = com.google.minijoe.compiler.ast.IncrementExpression;
	using LabelledStatement = com.google.minijoe.compiler.ast.LabelledStatement;
	using LogicalAndExpression = com.google.minijoe.compiler.ast.LogicalAndExpression;
	using LogicalOrExpression = com.google.minijoe.compiler.ast.LogicalOrExpression;
	using NewExpression = com.google.minijoe.compiler.ast.NewExpression;
	using NullLiteral = com.google.minijoe.compiler.ast.NullLiteral;
	using NumberLiteral = com.google.minijoe.compiler.ast.NumberLiteral;
	using ObjectLiteral = com.google.minijoe.compiler.ast.ObjectLiteral;
	using ObjectLiteralProperty = com.google.minijoe.compiler.ast.ObjectLiteralProperty;
	using Program = com.google.minijoe.compiler.ast.Program;
	using PropertyExpression = com.google.minijoe.compiler.ast.PropertyExpression;
	using ReturnStatement = com.google.minijoe.compiler.ast.ReturnStatement;
	using Statement = com.google.minijoe.compiler.ast.Statement;
	using StringLiteral = com.google.minijoe.compiler.ast.StringLiteral;
	using SwitchStatement = com.google.minijoe.compiler.ast.SwitchStatement;
	using ThisLiteral = com.google.minijoe.compiler.ast.ThisLiteral;
	using ThrowStatement = com.google.minijoe.compiler.ast.ThrowStatement;
	using TryStatement = com.google.minijoe.compiler.ast.TryStatement;
	using UnaryOperatorExpression = com.google.minijoe.compiler.ast.UnaryOperatorExpression;
	using VariableDeclaration = com.google.minijoe.compiler.ast.VariableDeclaration;
	using VariableExpression = com.google.minijoe.compiler.ast.VariableExpression;
	using VariableStatement = com.google.minijoe.compiler.ast.VariableStatement;
	using WhileStatement = com.google.minijoe.compiler.ast.WhileStatement;
	using WithStatement = com.google.minijoe.compiler.ast.WithStatement;

	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public class Parser
	{
	  private Lexer lexer;
	  private Token nextToken;
	  private bool seenNewline;

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public Parser(Lexer lexer) throws CompilerException
	  public Parser(Lexer lexer)
	  {
		this.lexer = lexer;

		readToken();
	  }

	  //
	  // program
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Program parseProgram() throws CompilerException
	  public virtual Program parseProgram()
	  {
		ArrayList statementVector = new ArrayList();

		statementVector.Add(parseSourceElement());

		while (nextToken != Token.EOF_Renamed)
		{
		  statementVector.Add(parseSourceElement());
		}

		return new Program(Util.vectorToStatementArray(statementVector));
	  }

	  //
	  // Statements
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement parseSourceElement() throws CompilerException
	  public virtual Statement parseSourceElement()
	  {
		if (nextToken == Token.KEYWORD_FUNCTION)
		{
		  return parseFunctionDeclaration();
		}
		else
		{
		  return parseStatement();
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseFunctionDeclaration() throws CompilerException
	  private Statement parseFunctionDeclaration()
	  {
		return new FunctionDeclaration(parseFunctionLiteral(true));
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement parseStatement() throws CompilerException
	  public virtual Statement parseStatement()
	  {
		Statement statement;
		int lineNumber;

		if (Config.LINENUMBER)
		{
		  lineNumber = LineNumber;
		}

		if (nextToken == Token.OPERATOR_SEMICOLON)
		{
		  readToken(Token.OPERATOR_SEMICOLON);
		  statement = new EmptyStatement();

		}
		else if (nextToken == Token.OPERATOR_OPENBRACE)
		{
		  statement = parseBlockStatement();

		}
		else if (nextToken == Token.KEYWORD_BREAK)
		{
		  statement = parseBreakStatement();

		}
		else if (nextToken == Token.KEYWORD_CONTINUE)
		{
		  statement = parseContinueStatement();

		}
		else if (nextToken == Token.KEYWORD_DO)
		{
		  statement = parseDoStatement();

		}
		else if (nextToken == Token.KEYWORD_FOR)
		{
		  statement = parseForStatement();

		}
		else if (nextToken == Token.KEYWORD_IF)
		{
		  statement = parseIfStatement();

		}
		else if (nextToken == Token.KEYWORD_RETURN)
		{
		  statement = parseReturnStatement();

		}
		else if (nextToken == Token.KEYWORD_THROW)
		{
		  statement = parseThrowStatement();

		}
		else if (nextToken == Token.KEYWORD_TRY)
		{
		  statement = parseTryStatement();

		}
		else if (nextToken == Token.KEYWORD_SWITCH)
		{
		  statement = parseSwitchStatement();

		}
		else if (nextToken == Token.KEYWORD_VAR)
		{
		  statement = parseVariableStatement();

		}
		else if (nextToken == Token.KEYWORD_WHILE)
		{
		  statement = parseWhileStatement();

		}
		else if (nextToken == Token.KEYWORD_WITH)
		{
		  statement = parseWithStatement();

		}
		else
		{
		  statement = parseExpressionStatement();

		}

		if (Config.LINENUMBER)
		{
		  statement.LineNumber = lineNumber;
		}

		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseBlockStatement() throws CompilerException
	  private Statement parseBlockStatement()
	  {
		readToken(Token.OPERATOR_OPENBRACE);

		ArrayList vector = new ArrayList();
		while (nextToken != Token.OPERATOR_CLOSEBRACE)
		{
		  vector.Add(parseStatement());
		}

		readToken(Token.OPERATOR_CLOSEBRACE);

		return new BlockStatement(Util.vectorToStatementArray(vector));
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseBreakStatement() throws CompilerException
	  private Statement parseBreakStatement()
	  {
		Identifier identifier = null;

		readToken(Token.KEYWORD_BREAK);

		if (nextToken != Token.OPERATOR_SEMICOLON)
		{
		  identifier = parseIdentifier();
		}

		readTokenSemicolon();

		return new BreakStatement(identifier);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseContinueStatement() throws CompilerException
	  private Statement parseContinueStatement()
	  {
		Identifier identifier = null;

		readToken(Token.KEYWORD_CONTINUE);

		if (nextToken != Token.OPERATOR_SEMICOLON)
		{
		  identifier = parseIdentifier();
		}

		readTokenSemicolon();

		return new ContinueStatement(identifier);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseDoStatement() throws CompilerException
	  private Statement parseDoStatement()
	  {
		Statement statement;
		Expression expression;

		readToken(Token.KEYWORD_DO);
		statement = parseStatement();
		readToken(Token.KEYWORD_WHILE);
		readToken(Token.OPERATOR_OPENPAREN);
		expression = parseExpression(true);
		readToken(Token.OPERATOR_CLOSEPAREN);

		return new DoStatement(statement, expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseExpressionStatement() throws CompilerException
	  private Statement parseExpressionStatement()
	  {
		Expression expression = parseExpression(true);

		// TODO there are comments in the v8 code about wrapping a
		// labelled try statement in a block and applying the label to the outer
		// block. we should consider doing something similar here if handling a
		// labelled try block proves problematic.

		if (expression is Identifier && nextToken == Token.OPERATOR_COLON)
		{
		  readToken(Token.OPERATOR_COLON);
		  return new LabelledStatement((Identifier) expression, parseStatement());
		}
		else
		{
		  readTokenSemicolon();
		  return new ExpressionStatement(expression);
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseForStatement() throws CompilerException
	  private Statement parseForStatement()
	  {
		Expression declaration = null;
		Expression initial = null;
		Expression condition = null;
		Expression increment = null;
		Expression variable = null;
		Expression expression = null;
		Statement statement = null;

		// 'for' statements can be one of the follow four productions:
		//
		// for ( ExpressionNoIn_opt; Expression_opt ; Expression_opt ) Statement
		// for ( var VariableDeclarationListNoIn; Expression_opt ; Expression_opt ) Statement
		// for ( LeftHandSideExpression in Expression ) Statement
		// for ( var VariableDeclarationNoIn in Expression ) Statement

		readToken(Token.KEYWORD_FOR);
		readToken(Token.OPERATOR_OPENPAREN);

		int state = 0;
		while (statement == null)
		{
		  switch (state)
		  {
			case 0:
			  // initial state
			  if (nextToken == Token.KEYWORD_VAR)
			  {
				state = 1;
			  }
			  else if (nextToken != Token.OPERATOR_SEMICOLON)
			  {
				state = 2;
			  }
			  else
			  {
				state = 5;
			  }
			  break;

			case 1:
			  // 'for' '(' 'var'
			  readToken(Token.KEYWORD_VAR);
			  declaration = parseVariableDeclaration(false);
			  if (nextToken == Token.KEYWORD_IN)
			  {
				variable = declaration;
				state = 3;
			  }
			  else
			  {
				state = 4;
			  }
			  break;

			case 2:
			  // 'for' '(' Expression
			  initial = parseExpression(false);
			  if (nextToken == Token.KEYWORD_IN)
			  {
				variable = initial;
				state = 3;
			  }
			  else
			  {
				state = 5;
			  }
			  break;

			case 3:
			  // 'for' '(' ... 'in'
			  readToken(Token.KEYWORD_IN);
			  expression = parseExpression(true);
			  readToken(Token.OPERATOR_CLOSEPAREN);

			  // 'for' '(' ... 'in' ... ')' Statement
			  statement = new ForInStatement(variable, expression, parseStatement());
			  break;

			case 4:
			  // 'for' '(' 'var' VariableDeclarationList
			  ArrayList declarationVector = new ArrayList();

			  declarationVector.Add(declaration);
			  while (nextToken == Token.OPERATOR_COMMA)
			  {
				readToken(Token.OPERATOR_COMMA);
				declarationVector.Add(parseVariableDeclaration(false));
			  }
			  initial = new VariableExpression(Util.vectorToDeclarationArray(declarationVector));

			  // fall through

				goto case 5;
			case 5:
			  // 'for' '(' ... ';'
			  readToken(Token.OPERATOR_SEMICOLON);

			  // 'for' '(' ... ';' ...
			  if (nextToken != Token.OPERATOR_SEMICOLON)
			  {
				condition = parseExpression(true);
			  }

			  // 'for' '(' ... ';' ... ';'
			  readToken(Token.OPERATOR_SEMICOLON);

			  // 'for' '(' ... ';' ... ';' ...
			  if (nextToken != Token.OPERATOR_CLOSEPAREN)
			  {
				increment = parseExpression(true);
			  }

			  // 'for' '(' ... ';' ... ';' ... ')'
			  readToken(Token.OPERATOR_CLOSEPAREN);

			  // 'for' '(' ... ';' ... ';' ... ')' Statement
			  statement = new ForStatement(initial, condition, increment, parseStatement());
			  break;
		  }
		}

		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseIfStatement() throws CompilerException
	  private Statement parseIfStatement()
	  {
		Expression expression = null;
		Statement trueStatement = null;
		Statement falseStatement = null;

		readToken(Token.KEYWORD_IF);
		readToken(Token.OPERATOR_OPENPAREN);
		expression = parseExpression(true);
		readToken(Token.OPERATOR_CLOSEPAREN);

		trueStatement = parseStatement();

		if (nextToken == Token.KEYWORD_ELSE)
		{
		  readToken(Token.KEYWORD_ELSE);
		  falseStatement = parseStatement();
		}

		return new IfStatement(expression, trueStatement, falseStatement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseReturnStatement() throws CompilerException
	  private Statement parseReturnStatement()
	  {
		Expression result = null;

		readToken(Token.KEYWORD_RETURN);

		if (nextToken != Token.OPERATOR_SEMICOLON)
		{
		  result = parseExpression(true);
		}

		readTokenSemicolon();

		return new ReturnStatement(result);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseSwitchStatement() throws CompilerException
	  private Statement parseSwitchStatement()
	  {
		ArrayList caseClauseVector = new ArrayList();
		bool defaultSeen = false;

		readToken(Token.KEYWORD_SWITCH);
		readToken(Token.OPERATOR_OPENPAREN);
		Expression switchExpression = parseExpression(true);
		readToken(Token.OPERATOR_CLOSEPAREN);

		readToken(Token.OPERATOR_OPENBRACE);

		while (nextToken != Token.OPERATOR_CLOSEBRACE)
		{
		  Expression caseExpression = null;
		  ArrayList caseStatements = new ArrayList();

		  if (nextToken == Token.KEYWORD_CASE)
		  {
			readToken(Token.KEYWORD_CASE);
			caseExpression = parseExpression(true);
			readToken(Token.OPERATOR_COLON);
		  }
		  else
		  {
			if (defaultSeen == false)
			{
			  defaultSeen = true;
			}
			else
			{
			  throwCompilerException("duplication default clause in switch statement");
			}

			readToken(Token.KEYWORD_DEFAULT);
			caseExpression = null;
			readToken(Token.OPERATOR_COLON);
		  }

		  while (nextToken != Token.KEYWORD_CASE && nextToken != Token.KEYWORD_DEFAULT && nextToken != Token.OPERATOR_CLOSEBRACE)
		  {
			caseStatements.Add(parseStatement());
		  }

		  caseClauseVector.Add(new CaseStatement(caseExpression, Util.vectorToStatementArray(caseStatements)));
		}

		readToken(Token.OPERATOR_CLOSEBRACE);

		CaseStatement[] caseClauseArray = new CaseStatement[caseClauseVector.Count];

		caseClauseVector.CopyTo(caseClauseArray);

		return new SwitchStatement(switchExpression, caseClauseArray);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseThrowStatement() throws CompilerException
	  private Statement parseThrowStatement()
	  {
		readToken(Token.KEYWORD_THROW);

		return new ThrowStatement(parseExpression(true));
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseTryStatement() throws CompilerException
	  private Statement parseTryStatement()
	  {
		Statement tryBlock = null;
		Identifier catchIdentifier = null;
		Statement catchBlock = null;
		Statement finallyBlock = null;

		readToken(Token.KEYWORD_TRY);
		tryBlock = parseBlockStatement();

		if (nextToken != Token.KEYWORD_CATCH && nextToken != Token.KEYWORD_FINALLY)
		{
		  throwCompilerException("catch or finally expected after try");
		}

		if (nextToken == Token.KEYWORD_CATCH)
		{
		  readToken(Token.KEYWORD_CATCH);
		  readToken(Token.OPERATOR_OPENPAREN);
		  catchIdentifier = parseIdentifier();
		  readToken(Token.OPERATOR_CLOSEPAREN);
		  catchBlock = parseBlockStatement();
		}

		if (nextToken == Token.KEYWORD_FINALLY)
		{
		  readToken(Token.KEYWORD_FINALLY);
		  finallyBlock = parseBlockStatement();
		}

		return new TryStatement(tryBlock, catchIdentifier, catchBlock, finallyBlock);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseVariableStatement() throws CompilerException
	  private Statement parseVariableStatement()
	  {
		ArrayList declarationVector = new ArrayList();

		readToken(Token.KEYWORD_VAR);

		// there must be at least one variable declaration

		declarationVector.Add(parseVariableDeclaration(true));
		while (nextToken == Token.OPERATOR_COMMA)
		{
		  readToken(Token.OPERATOR_COMMA);
		  declarationVector.Add(parseVariableDeclaration(true));
		}

		readTokenSemicolon();

		return new VariableStatement(Util.vectorToDeclarationArray(declarationVector));
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseWhileStatement() throws CompilerException
	  private Statement parseWhileStatement()
	  {
		Statement statement;
		Expression expression;

		readToken(Token.KEYWORD_WHILE);
		readToken(Token.OPERATOR_OPENPAREN);
		expression = parseExpression(true);
		readToken(Token.OPERATOR_CLOSEPAREN);
		statement = parseStatement();

		return new WhileStatement(expression, statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Statement parseWithStatement() throws CompilerException
	  private Statement parseWithStatement()
	  {
		Statement statement;
		Expression expression;

		readToken(Token.KEYWORD_WITH);
		readToken(Token.OPERATOR_OPENPAREN);
		expression = parseExpression(true);
		readToken(Token.OPERATOR_CLOSEPAREN);
		statement = parseStatement();

		return new WithStatement(expression, statement);
	  }

	  //
	  // Expressions
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.VariableDeclaration parseVariableDeclaration(boolean inFlag) throws CompilerException
	  private VariableDeclaration parseVariableDeclaration(bool inFlag)
	  {
		Identifier identifier = parseIdentifier();
		Expression initializer = null;

		if (nextToken == Token.OPERATOR_ASSIGNMENT)
		{
		  readToken(Token.OPERATOR_ASSIGNMENT);
		  initializer = parseAssignmentExpression(inFlag);
		}

		return new VariableDeclaration(identifier, initializer);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseExpression(boolean inFlag) throws CompilerException
	  private Expression parseExpression(bool inFlag)
	  {
		Expression left = parseAssignmentExpression(inFlag);

		// comma expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_COMMA)
		  {
			readToken(Token.OPERATOR_COMMA);
			Expression right = parseAssignmentExpression(inFlag);
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_COMMA);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseAssignmentExpression(boolean inFlag) throws CompilerException
	  private Expression parseAssignmentExpression(bool inFlag)
	  {
		Expression left = parseConditionalExpression(inFlag);

		// assignment expressions are right associative
		if (nextToken == Token.OPERATOR_ASSIGNMENT)
		{
		  readToken();
		  return new AssignmentExpression(left, parseAssignmentExpression(inFlag));
		}
		else if (nextToken == Token.OPERATOR_ASSIGNMENT || nextToken == Token.OPERATOR_MULTIPLYASSIGNMENT || nextToken == Token.OPERATOR_DIVIDEASSIGNMENT || nextToken == Token.OPERATOR_MODULOASSIGNMENT || nextToken == Token.OPERATOR_PLUSASSIGNMENT || nextToken == Token.OPERATOR_MINUSASSIGNMENT || nextToken == Token.OPERATOR_SHIFTLEFTASSIGNMENT || nextToken == Token.OPERATOR_SHIFTRIGHTASSIGNMENT || nextToken == Token.OPERATOR_SHIFTRIGHTUNSIGNEDASSIGNMENT || nextToken == Token.OPERATOR_BITWISEANDASSIGNMENT || nextToken == Token.OPERATOR_BITWISEORASSIGNMENT || nextToken == Token.OPERATOR_BITWISEXORASSIGNMENT)
		{
		  Token op = nextToken;
		  readToken();
		  return new AssignmentOperatorExpression(left, parseAssignmentExpression(inFlag), op);
		}
		else
		{
		  return left;
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseConditionalExpression(boolean inFlag) throws CompilerException
	  private Expression parseConditionalExpression(bool inFlag)
	  {
		Expression expression = parseLogicalOrExpression(inFlag);

		// conditional expressions are right associative
		if (nextToken == Token.OPERATOR_CONDITIONAL)
		{
		  readToken(Token.OPERATOR_CONDITIONAL);
		  Expression trueExpression = parseAssignmentExpression(inFlag);
		  readToken(Token.OPERATOR_COLON);
		  Expression falseExpression = parseAssignmentExpression(inFlag);
		  return new ConditionalExpression(expression, trueExpression, falseExpression);
		}
		else
		{
		  return expression;
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseLogicalOrExpression(boolean inFlag) throws CompilerException
	  private Expression parseLogicalOrExpression(bool inFlag)
	  {
		Expression left = parseLogicalAndExpression(inFlag);
		Expression right;

		// logical or expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_LOGICALOR)
		  {
			readToken(Token.OPERATOR_LOGICALOR);
			right = parseLogicalAndExpression(inFlag);
			left = new LogicalOrExpression(left, right);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseLogicalAndExpression(boolean inFlag) throws CompilerException
	  private Expression parseLogicalAndExpression(bool inFlag)
	  {
		Expression left = parseBitwiseOrExpression(inFlag);
		Expression right;

		// logical and expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_LOGICALAND)
		  {
			readToken(Token.OPERATOR_LOGICALAND);
			right = parseBitwiseOrExpression(inFlag);
			left = new LogicalAndExpression(left, right);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseBitwiseOrExpression(boolean inFlag) throws CompilerException
	  private Expression parseBitwiseOrExpression(bool inFlag)
	  {
		Expression left = parseBitwiseXorExpression(inFlag);
		Expression right;

		// bitwise or expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_BITWISEOR)
		  {
			readToken(Token.OPERATOR_BITWISEOR);
			right = parseBitwiseXorExpression(inFlag);
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_BITWISEOR);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseBitwiseXorExpression(boolean inFlag) throws CompilerException
	  private Expression parseBitwiseXorExpression(bool inFlag)
	  {
		Expression left = parseBitwiseAndExpression(inFlag);
		Expression right;

		// bitwise xor expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_BITWISEXOR)
		  {
			readToken(Token.OPERATOR_BITWISEXOR);
			right = parseBitwiseAndExpression(inFlag);
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_BITWISEXOR);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseBitwiseAndExpression(boolean inFlag) throws CompilerException
	  private Expression parseBitwiseAndExpression(bool inFlag)
	  {
		Expression left = parseEqualityExpression(inFlag);
		Expression right;

		// bitwise and expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_BITWISEAND)
		  {
			readToken(Token.OPERATOR_BITWISEAND);
			right = parseEqualityExpression(inFlag);
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_BITWISEAND);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseEqualityExpression(boolean inFlag) throws CompilerException
	  private Expression parseEqualityExpression(bool inFlag)
	  {
		Expression left = parseRelationalExpression(inFlag);
		Expression right;

		// equality expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_EQUALEQUAL)
		  {
			readToken(Token.OPERATOR_EQUALEQUAL);
			right = parseRelationalExpression(inFlag);
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_EQUALEQUAL);
		  }
		  else if (nextToken == Token.OPERATOR_NOTEQUAL)
		  {
			readToken(Token.OPERATOR_NOTEQUAL);
			right = parseRelationalExpression(inFlag);
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_NOTEQUAL);
		  }
		  else if (nextToken == Token.OPERATOR_EQUALEQUALEQUAL)
		  {
			readToken(Token.OPERATOR_EQUALEQUALEQUAL);
			right = parseRelationalExpression(inFlag);
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_EQUALEQUALEQUAL);
		  }
		  else if (nextToken == Token.OPERATOR_NOTEQUALEQUAL)
		  {
			readToken(Token.OPERATOR_NOTEQUALEQUAL);
			right = parseRelationalExpression(inFlag);
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_NOTEQUALEQUAL);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseRelationalExpression(boolean inFlag) throws CompilerException
	  private Expression parseRelationalExpression(bool inFlag)
	  {
		Expression left = parseShiftExpression();
		Expression right;

		// relational expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_LESSTHAN)
		  {
			readToken(Token.OPERATOR_LESSTHAN);
			right = parseShiftExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_LESSTHAN);
		  }
		  else if (nextToken == Token.OPERATOR_GREATERTHAN)
		  {
			readToken(Token.OPERATOR_GREATERTHAN);
			right = parseShiftExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_GREATERTHAN);
		  }
		  else if (nextToken == Token.OPERATOR_LESSTHANOREQUAL)
		  {
			readToken(Token.OPERATOR_LESSTHANOREQUAL);
			right = parseShiftExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_LESSTHANOREQUAL);
		  }
		  else if (nextToken == Token.OPERATOR_GREATERTHANOREQUAL)
		  {
			readToken(Token.OPERATOR_GREATERTHANOREQUAL);
			right = parseShiftExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_GREATERTHANOREQUAL);
		  }
		  else if (nextToken == Token.KEYWORD_INSTANCEOF)
		  {
			readToken(Token.KEYWORD_INSTANCEOF);
			right = parseShiftExpression();
			left = new BinaryOperatorExpression(left, right, Token.KEYWORD_INSTANCEOF);
		  }
		  else if (inFlag && nextToken == Token.KEYWORD_IN)
		  {
			readToken(Token.KEYWORD_IN);
			right = parseShiftExpression();
			left = new BinaryOperatorExpression(left, right, Token.KEYWORD_IN);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseShiftExpression() throws CompilerException
	  private Expression parseShiftExpression()
	  {
		Expression left = parseAdditionExpression();
		Expression right;

		// shift expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_SHIFTLEFT)
		  {
			readToken(Token.OPERATOR_SHIFTLEFT);
			right = parseAdditionExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_SHIFTLEFT);
		  }
		  else if (nextToken == Token.OPERATOR_SHIFTRIGHT)
		  {
			readToken(Token.OPERATOR_SHIFTRIGHT);
			right = parseAdditionExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_SHIFTRIGHT);
		  }
		  else if (nextToken == Token.OPERATOR_SHIFTRIGHTUNSIGNED)
		  {
			readToken(Token.OPERATOR_SHIFTRIGHTUNSIGNED);
			right = parseAdditionExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_SHIFTRIGHTUNSIGNED);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseAdditionExpression() throws CompilerException
	  private Expression parseAdditionExpression()
	  {
		Expression left = parseMultiplyExpression();
		Expression right;

		// addition expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_PLUS)
		  {
			readToken(Token.OPERATOR_PLUS);
			right = parseMultiplyExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_PLUS);
		  }
		  else if (nextToken == Token.OPERATOR_MINUS)
		  {
			readToken(Token.OPERATOR_MINUS);
			right = parseMultiplyExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_MINUS);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseMultiplyExpression() throws CompilerException
	  private Expression parseMultiplyExpression()
	  {
		Expression left = parseUnaryExpression();
		Expression right;

		// multiplicative expressions are left associative
		while (true)
		{
		  if (nextToken == Token.OPERATOR_MULTIPLY)
		  {
			readToken(Token.OPERATOR_MULTIPLY);
			right = parseUnaryExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_MULTIPLY);
		  }
		  else if (nextToken == Token.OPERATOR_DIVIDE)
		  {
			readToken(Token.OPERATOR_DIVIDE);
			right = parseUnaryExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_DIVIDE);
		  }
		  else if (nextToken == Token.OPERATOR_MODULO)
		  {
			readToken(Token.OPERATOR_MODULO);
			right = parseUnaryExpression();
			left = new BinaryOperatorExpression(left, right, Token.OPERATOR_MODULO);
		  }
		  else
		  {
			return left;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseUnaryExpression() throws CompilerException
	  private Expression parseUnaryExpression()
	  {
		// TODO parse '-' numeric literal directly into literals,
		// to ensure that -0 keeps its proper value.

		// unary expressions are right associative
		if (nextToken == Token.OPERATOR_PLUSPLUS)
		{
		  readToken(Token.OPERATOR_PLUSPLUS);
		  return new IncrementExpression(parseUnaryExpression(), 1, false);
		}
		else if (nextToken == Token.OPERATOR_MINUSMINUS)
		{
		  readToken(Token.OPERATOR_MINUSMINUS);
		  return new IncrementExpression(parseUnaryExpression(), -1, false);
		}
		else if (nextToken == Token.OPERATOR_PLUS || nextToken == Token.OPERATOR_MINUS || nextToken == Token.OPERATOR_BITWISENOT || nextToken == Token.OPERATOR_LOGICALNOT || nextToken == Token.KEYWORD_VOID || nextToken == Token.KEYWORD_TYPEOF)
		{
		  Token token = nextToken;
		  readToken();
		  UnaryOperatorExpression result = new UnaryOperatorExpression(parseUnaryExpression(), token);
		  return result;
		}
		else if (nextToken == Token.KEYWORD_DELETE)
		{
		  readToken(Token.KEYWORD_DELETE);
		  return new DeleteExpression(parseUnaryExpression());
		}
		else
		{
		  return parsePostfixExpression();
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parsePostfixExpression() throws CompilerException
	  private Expression parsePostfixExpression()
	  {
		// TODO this can be merged with parseUnary().

		Expression expression = parseMemberExpression(false);

		// postfix expressions aren't associative
		if (nextToken == Token.OPERATOR_PLUSPLUS)
		{
		  readToken(Token.OPERATOR_PLUSPLUS);
		  return new IncrementExpression(expression, 1, true);
		}
		else if (nextToken == Token.OPERATOR_MINUSMINUS)
		{
		  readToken(Token.OPERATOR_MINUSMINUS);
		  return new IncrementExpression(expression, -1, true);
		}
		else
		{
		  return expression;
		}
	  }

	  /// <summary>
	  /// The grammar for the 'new' keyword is a little complicated. The keyword
	  /// 'new' can occur in either a NewExpression (where its not followed by
	  /// an argument list) or in MemberExpresison (where it is followed by an
	  /// argument list). The intention seems to be that an argument list should
	  /// bind to any unmatched 'new' keyword to the left in the same expression
	  /// if possible, otherwise an argument list is taken as a call expression.
	  /// 
	  /// Since the rest of the productions for NewExpressions and CallExpressions
	  /// are similar we roll these two into one routine with a parameter to
	  /// indicate whether we're currently parsing a 'new' expression or not.
	  /// </summary>
	  /// <param name="newFlag"> if we're currently parsing a 'new' expression </param>
	  /// <returns> an expression </returns>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parseMemberExpression(boolean newFlag) throws CompilerException
	  private Expression parseMemberExpression(bool newFlag)
	  {
		Expression expression;

		// new expressions are right associative
		if (nextToken == Token.KEYWORD_NEW)
		{
		  Expression name;

		  readToken(Token.KEYWORD_NEW);
		  name = parseMemberExpression(true);

		  if (nextToken == Token.OPERATOR_OPENPAREN)
		  {
			Expression[] arguments = parseArgumentList();
			expression = new NewExpression(name, arguments);
		  }
		  else
		  {
			expression = new NewExpression(name, null);
		  }

		}
		else if (nextToken == Token.KEYWORD_FUNCTION)
		{
		  expression = parseFunctionLiteral(false);

		}
		else
		{
		  expression = parsePrimaryExpression();
		}

		// call expressions are left associative
		while (true)
		{
		  if (!newFlag && nextToken == Token.OPERATOR_OPENPAREN)
		  {
			Expression[] arguments = parseArgumentList();
			expression = new CallExpression(expression, arguments);
		  }
		  else if (nextToken == Token.OPERATOR_OPENSQUARE)
		  {
			readToken(Token.OPERATOR_OPENSQUARE);
			Expression property = parseExpression(true);
			readToken(Token.OPERATOR_CLOSESQUARE);
			expression = new PropertyExpression(expression, property);
		  }
		  else if (nextToken == Token.OPERATOR_DOT)
		  {
			// transform x.bar to x["bar"]
			readToken(Token.OPERATOR_DOT);
			Identifier identifier = parseIdentifier();
			expression = new PropertyExpression(expression, new StringLiteral(identifier.@string));
		  }
		  else
		  {
			return expression;
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression[] parseArgumentList() throws CompilerException
	  private Expression[] parseArgumentList()
	  {
		ArrayList argumentVector = new ArrayList();

		readToken(Token.OPERATOR_OPENPAREN);

		if (nextToken != Token.OPERATOR_CLOSEPAREN)
		{
		  argumentVector.Add(parseAssignmentExpression(true));
		  while (nextToken == Token.OPERATOR_COMMA)
		  {
			readToken(Token.OPERATOR_COMMA);
			argumentVector.Add(parseAssignmentExpression(true));
		  }
		}

		readToken(Token.OPERATOR_CLOSEPAREN);

		return Util.vectorToExpressionArray(argumentVector);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Expression parsePrimaryExpression() throws CompilerException
	  private Expression parsePrimaryExpression()
	  {
		if (nextToken == Token.KEYWORD_THIS)
		{
		  readToken(Token.KEYWORD_THIS);
		  return new ThisLiteral();

		}
		else if (nextToken == Token.KEYWORD_NULL)
		{
		  readToken(Token.KEYWORD_NULL);
		  return new NullLiteral();

		}
		else if (nextToken == Token.KEYWORD_TRUE)
		{
		  readToken(Token.KEYWORD_TRUE);
		  return new BooleanLiteral(true);

		}
		else if (nextToken == Token.KEYWORD_FALSE)
		{
		  readToken(Token.KEYWORD_FALSE);
		  return new BooleanLiteral(false);

		}
		else if (nextToken == Token.OPERATOR_OPENPAREN)
		{
		  readToken(Token.OPERATOR_OPENPAREN);
		  Expression expression = parseExpression(true);
		  readToken(Token.OPERATOR_CLOSEPAREN);
		  return expression;

		}
		else if (nextToken == Token.OPERATOR_OPENBRACE)
		{
		  return parseObjectLiteral();

		}
		else if (nextToken == Token.OPERATOR_OPENSQUARE)
		{
		  return parseArrayLiteral();

		}
		else if (nextToken.Identifier)
		{
		  return parseIdentifier();

		}
		else if (nextToken.StringLiteral)
		{
		  return parseStringLiteral();

		}
		else if (nextToken.NumericLiteral)
		{
		  return parseNumericLiteral();

		}
		else
		{
		  throwCompilerException("identifier or literal expected at token: " + nextToken);

		}

		return null;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.ArrayLiteral parseArrayLiteral() throws CompilerException
	  private ArrayLiteral parseArrayLiteral()
	  {
		ArrayList arrayElements = new ArrayList();

		readToken(Token.OPERATOR_OPENSQUARE);

		while (nextToken != Token.OPERATOR_CLOSESQUARE)
		{
		  if (nextToken == Token.OPERATOR_COMMA)
		  {
			arrayElements.Add(null);
		  }
		  else
		  {
			arrayElements.Add(parseAssignmentExpression(true));
		  }

		  if (nextToken != Token.OPERATOR_CLOSESQUARE)
		  {
			readToken(Token.OPERATOR_COMMA);
		  }
		}

		readToken(Token.OPERATOR_CLOSESQUARE);

		return new ArrayLiteral(Util.vectorToExpressionArray(arrayElements));
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.FunctionLiteral parseFunctionLiteral(boolean nameFlag) throws CompilerException
	  private FunctionLiteral parseFunctionLiteral(bool nameFlag)
	  {
		Identifier name = null;
		ArrayList parameterVector = new ArrayList();
		ArrayList statementVector = new ArrayList();

		readToken(Token.KEYWORD_FUNCTION);

		if (nameFlag || nextToken != Token.OPERATOR_OPENPAREN)
		{
		  name = parseIdentifier();
		}

		// function literals may have zero or more parameters.

		readToken(Token.OPERATOR_OPENPAREN);

		if (nextToken != Token.OPERATOR_CLOSEPAREN)
		{
		  parameterVector.Add(parseIdentifier());

		  while (nextToken != Token.OPERATOR_CLOSEPAREN)
		  {
			readToken(Token.OPERATOR_COMMA);
			parameterVector.Add(parseIdentifier());
		  }
		}

		readToken(Token.OPERATOR_CLOSEPAREN);

		// function literals are required the have at least one SourceElement.

		readToken(Token.OPERATOR_OPENBRACE);

		// statementVector.addElement(parseStatement());

		while (nextToken != Token.OPERATOR_CLOSEBRACE)
		{
		  statementVector.Add(parseSourceElement());
		}

		readToken(Token.OPERATOR_CLOSEBRACE);

		return new FunctionLiteral(name, Util.vectorToIdentifierArray(parameterVector), Util.vectorToStatementArray(statementVector));
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.ObjectLiteral parseObjectLiteral() throws CompilerException
	  private ObjectLiteral parseObjectLiteral()
	  {
		ArrayList propertyVector = new ArrayList();

		readToken(Token.OPERATOR_OPENBRACE);

		while (nextToken != Token.OPERATOR_CLOSEBRACE)
		{
		  propertyVector.Add(parseObjectLiteralProperty());

		  while (nextToken == Token.OPERATOR_COMMA)
		  {
			readToken(Token.OPERATOR_COMMA);
			propertyVector.Add(parseObjectLiteralProperty());
		  }
		}

		readToken(Token.OPERATOR_CLOSEBRACE);

		ObjectLiteralProperty[] propertyArray = new ObjectLiteralProperty[propertyVector.Count];

		propertyVector.CopyTo(propertyArray);

		return new ObjectLiteral(propertyArray);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.ObjectLiteralProperty parseObjectLiteralProperty() throws CompilerException
	  private ObjectLiteralProperty parseObjectLiteralProperty()
	  {
		Expression propertyName = null;
		Expression propertyValue = null;

		if (nextToken.Identifier)
		{
		  propertyName = new StringLiteral(parseIdentifier().@string);
		}
		else if (nextToken.StringLiteral)
		{
		  propertyName = parseStringLiteral();
		}
		else if (nextToken.NumericLiteral)
		{
		  propertyName = parseNumericLiteral();
		}
		else
		{
		  throwCompilerException("identifier or numeric literal expected");
		}

		readToken(Token.OPERATOR_COLON);

		propertyValue = parseAssignmentExpression(true);

		return new ObjectLiteralProperty(propertyName, propertyValue);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.Identifier parseIdentifier() throws CompilerException
	  private Identifier parseIdentifier()
	  {
		Identifier identifier = null;

		if (nextToken.Type == Token.TYPE_IDENTIFIER)
		{
		  identifier = new Identifier(nextToken.Value);
		}
		else
		{
		  throwCompilerException("identifier or numeric literal expected");
		}

		readToken();

		return identifier;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.StringLiteral parseStringLiteral() throws CompilerException
	  private StringLiteral parseStringLiteral()
	  {
		string @string = null;

		if (nextToken.Type == Token.TYPE_STRING)
		{
		  @string = nextToken.Value;
		}
		else
		{
		  throwCompilerException("string literal expected");
		}

		readToken();

		return new StringLiteral(@string);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private com.google.minijoe.compiler.ast.NumberLiteral parseNumericLiteral() throws CompilerException
	  private NumberLiteral parseNumericLiteral()
	  {
		double value = 0.0;

		try
		{
		  switch (nextToken.Type)
		  {
			case Token.TYPE_FLOAT:
			  value = Convert.ToDouble(nextToken.Value);
			  break;

			case Token.TYPE_DECIMAL:
			  value = Convert.ToInt64(nextToken.Value);
			  break;

			case Token.TYPE_OCTAL:
			  value = Convert.ToInt64(nextToken.Value.Substring(1), 8);
			  break;

			case Token.TYPE_HEXADECIMAL:
			  value = Convert.ToInt64(nextToken.Value.Substring(2), 16);
			  break;

			default:
			  throwCompilerException("numeric literal expected");
		  }
		}
		catch (NumberFormatException)
		{
		  value = double.NaN;
		}

		readToken();

		return new NumberLiteral(value);
	  }

	  //
	  // Tokens
	  //

	  private int LineNumber
	  {
		  get
		  {
			return lexer.LineNumber;
		  }
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void readToken() throws CompilerException
	  private void readToken()
	  {
		seenNewline = false;

		do
		{
		  nextToken = lexer.nextToken();

		  if (nextToken.EOF || nextToken.NewLine)
		  {
			seenNewline = true;
		  }
		} while (nextToken.Whitespace);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void readToken(Token token) throws CompilerException
	  private void readToken(Token token)
	  {
		if (nextToken == token)
		{
		  readToken();
		}
		else
		{
		  throwCompilerException("expected '" + token.Value + "'");
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void readTokenSemicolon() throws CompilerException
	  private void readTokenSemicolon()
	  {
		if (nextToken == Token.OPERATOR_SEMICOLON)
		{
		  readToken();
		}
		else if (nextToken == Token.OPERATOR_CLOSEBRACE)
		{
		  // semicolon insertion
		}
		else if (seenNewline)
		{
		  // semicolon insertion
		}
		else
		{
		  throwCompilerException("expected '" + Token.OPERATOR_SEMICOLON.Value + "'");
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void throwCompilerException(String message) throws CompilerException
	  private void throwCompilerException(string message)
	  {
		throw new CompilerException(message, LineNumber);
	  }
	}

}