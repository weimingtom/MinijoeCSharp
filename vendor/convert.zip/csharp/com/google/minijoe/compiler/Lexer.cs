using System.Collections;
using System.Text;

// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler
{

	/// <summary>
	/// Lexer is a lexical analyzer for MiniJoe, a JavaScript runtime for J2ME.
	/// 
	/// <para>This lexical analyzer handles all parts of the ECMAScript v3
	/// specification, except for:
	/// <ul>
	/// <li>no support for regular expressions
	/// <li>limited Unicode character support
	/// </ul>
	/// 
	/// </para>
	/// </summary>
	/// <seealso cref= <a href="http://wiki.corp.google.com/twiki/bin/view/Main/MiniJoe">MiniJoe</a> </seealso>
	/// <seealso cref= <a href="http://www.mozilla.org/js/language/E262-3.pdf">ECMAScript v3 Specification</a>
	/// 
	/// @author Andy Hayward </seealso>
	public class Lexer
	{
	  private const int BASE_HEXADECIMAL = 16;
	  private const int BASE_OCTAL = 8;

	  private const int TOKENIZENUMERIC_ENTRY_POINT = 0;
	  private const int TOKENIZENUMERIC_LEADING_ZERO = 1;
	  private const int TOKENIZENUMERIC_LEADING_DECIMAL = 2;
	  private const int TOKENIZENUMERIC_OCTAL_LITERAL = 3;
	  private const int TOKENIZENUMERIC_LEADING_OX = 4;
	  private const int TOKENIZENUMERIC_HEXADECIMAL_LITERAL = 5;
	  private const int TOKENIZENUMERIC_DECIMAL_LITERAL = 6;
	  private const int TOKENIZENUMERIC_DECIMAL_POINT = 7;
	  private const int TOKENIZENUMERIC_FRACTIONAL_PART = 8;
	  private const int TOKENIZENUMERIC_EXPONENT_SYMBOL = 9;
	  private const int TOKENIZENUMERIC_EXPONENT_SIGN = 10;
	  private const int TOKENIZENUMERIC_EXPONENT_PART = 11;
	  private const int TOKENIZENUMERIC_UNREAD_TWO = 12;
	  private const int TOKENIZENUMERIC_UNREAD_ONE = 13;
	  private const int TOKENIZENUMERIC_RETURN_FLOAT = 14;
	  private const int TOKENIZENUMERIC_RETURN_DECIMAL = 15;
	  private const int TOKENIZENUMERIC_RETURN_OCTAL = 16;
	  private const int TOKENIZENUMERIC_RETURN_HEXADECIMAL = 17;
	  private const int TOKENIZENUMERIC_RETURN_OPERATOR_DOT = 18;

	  private Hashtable keywords = null;
	  private string input = null;
	  internal int lineNumber = 1;
	  internal int maxPosition;
	  internal int curPosition;
	  internal int oldPosition;
	  internal int c;

	  /// <summary>
	  /// Creates a Lexer for the specified source string.
	  /// </summary>
	  /// <param name="input"> the string to tokenize </param>
	  public Lexer(string input)
	  {
		if (input == null)
		{
		  throw new System.ArgumentException();
		}

		// initialization

		this.input = input;

		initKeywords();

		// prime the main loop

		maxPosition = input.Length;
		oldPosition = 0;
		curPosition = 0;

		c = curPosition < maxPosition ? input[curPosition] : -1;
	  }

	  /// <summary>
	  /// Adds a keyword token to the keyword hashtable.
	  /// </summary>
	  private void addKeyword(Token keyword)
	  {
		keywords[keyword.Value] = keyword;
	  }

	  /// <summary>
	  /// Gets the line number of the most recently returned token.
	  /// </summary>
	  public virtual int LineNumber
	  {
		  get
		  {
			return lineNumber;
		  }
	  }

	  /// <summary>
	  /// Initializes the keyword map.
	  /// </summary>
	  private void initKeywords()
	  {
		keywords = new Hashtable();

		// keywords

		addKeyword(Token.KEYWORD_BREAK);
		addKeyword(Token.KEYWORD_CASE);
		addKeyword(Token.KEYWORD_CATCH);
		addKeyword(Token.KEYWORD_CONTINUE);
		addKeyword(Token.KEYWORD_DEFAULT);
		addKeyword(Token.KEYWORD_DELETE);
		addKeyword(Token.KEYWORD_DO);
		addKeyword(Token.KEYWORD_ELSE);
		addKeyword(Token.KEYWORD_FALSE);
		addKeyword(Token.KEYWORD_FINALLY);
		addKeyword(Token.KEYWORD_FOR);
		addKeyword(Token.KEYWORD_FUNCTION);
		addKeyword(Token.KEYWORD_IF);
		addKeyword(Token.KEYWORD_IN);
		addKeyword(Token.KEYWORD_INSTANCEOF);
		addKeyword(Token.KEYWORD_NEW);
		addKeyword(Token.KEYWORD_NULL);
		addKeyword(Token.KEYWORD_RETURN);
		addKeyword(Token.KEYWORD_SWITCH);
		addKeyword(Token.KEYWORD_THIS);
		addKeyword(Token.KEYWORD_THROW);
		addKeyword(Token.KEYWORD_TRUE);
		addKeyword(Token.KEYWORD_TRY);
		addKeyword(Token.KEYWORD_TYPEOF);
		addKeyword(Token.KEYWORD_VAR);
		addKeyword(Token.KEYWORD_VOID);
		addKeyword(Token.KEYWORD_WHILE);
		addKeyword(Token.KEYWORD_WITH);

		// reserved keywords

		addKeyword(Token.KEYWORD_ABSTRACT);
		addKeyword(Token.KEYWORD_BOOLEAN);
		addKeyword(Token.KEYWORD_BYTE);
		addKeyword(Token.KEYWORD_CHAR);
		addKeyword(Token.KEYWORD_CLASS);
		addKeyword(Token.KEYWORD_CONST);
		addKeyword(Token.KEYWORD_DEBUGGER);
		addKeyword(Token.KEYWORD_DOUBLE);
		addKeyword(Token.KEYWORD_ENUM);
		addKeyword(Token.KEYWORD_EXPORT);
		addKeyword(Token.KEYWORD_EXTENDS);
		addKeyword(Token.KEYWORD_FINAL);
		addKeyword(Token.KEYWORD_FLOAT);
		addKeyword(Token.KEYWORD_GOTO);
		addKeyword(Token.KEYWORD_IMPLEMENTS);
		addKeyword(Token.KEYWORD_IMPORT);
		addKeyword(Token.KEYWORD_INT);
		addKeyword(Token.KEYWORD_INTERFACE);
		addKeyword(Token.KEYWORD_LONG);
		addKeyword(Token.KEYWORD_NATIVE);
		addKeyword(Token.KEYWORD_PACKAGE);
		addKeyword(Token.KEYWORD_PRIVATE);
		addKeyword(Token.KEYWORD_PROTECTED);
		addKeyword(Token.KEYWORD_PUBLIC);
		addKeyword(Token.KEYWORD_SHORT);
		addKeyword(Token.KEYWORD_STATIC);
		addKeyword(Token.KEYWORD_SUPER);
		addKeyword(Token.KEYWORD_SYNCHRONIZED);
		addKeyword(Token.KEYWORD_THROWS);
		addKeyword(Token.KEYWORD_TRANSIENT);
		addKeyword(Token.KEYWORD_VOLATILE);
	  }

	  /// <summary>
	  /// Returns true if the end of input has been reached.
	  /// </summary>
	  private bool EOF
	  {
		  get
		  {
			return c == -1;
		  }
	  }

	  /// <summary>
	  /// Returns true if the current character is a line terminator.
	  /// </summary>
	  private bool LineTerminator
	  {
		  get
		  {
			return c == '\n' || c == '\r' || c == '\u2028' || c == '\u2029';
		  }
	  }

	  /// <summary>
	  /// Returns true if the current character is a whitespace character.
	  /// </summary>
	  private bool Whitespace
	  {
		  get
		  {
			return c == '\u0009' || c == '\u000B' || c == '\u000C' || c == '\u0020' || c == '\u00A0';
		  }
	  }

	  /// <summary>
	  /// Returns true if the current character is an octal digit.
	  /// </summary>
	  private bool OctalDigit
	  {
		  get
		  {
			return c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7';
		  }
	  }

	  /// <summary>
	  /// Returns true if the current character is a decimal digit.
	  /// </summary>
	  private bool DecimalDigit
	  {
		  get
		  {
			return c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9';
		  }
	  }

	  /// <summary>
	  /// Returns true if the current character is a hexadecimal digit.
	  /// </summary>
	  private bool HexadecimalDigit
	  {
		  get
		  {
			return c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9' || c == 'a' || c == 'b' || c == 'c' || c == 'd' || c == 'e' || c == 'f' || c == 'A' || c == 'B' || c == 'C' || c == 'D' || c == 'E' || c == 'F';
		  }
	  }

	  /// <summary>
	  /// Returns true if the current character is a valid identifier start
	  /// character.
	  /// </summary>
	  private bool IdentifierStart
	  {
		  get
		  {
			return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '$' || c == '_';
		  }
	  }

	  /// <summary>
	  /// Returns true if the current character is a valid as part of an identifier.
	  /// </summary>
	  private bool IdentifierPart
	  {
		  get
		  {
			return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '$' || c == '_';
		  }
	  }

	  /// <summary>
	  /// Consumes the current character and reads the next.
	  /// </summary>
	  private void readChar()
	  {
		curPosition++;

		if (curPosition < maxPosition)
		{
		  c = input[curPosition];
		}
		else
		{
		  c = -1;
		}
	  }

	  /// <summary>
	  /// Unread the current character.  This MUST NOT be used to unread past a
	  /// line terminator character.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void unreadChar() throws CompilerException
	  private void unreadChar()
	  {
		if (curPosition > 0)
		{
		  if (LineTerminator)
		  {
			throw new CompilerException("current character must not be a line terminator");
		  }
		  c = input[--curPosition];
		}
		else
		{
		  c = -1;
		}
	  }

	  /// <summary>
	  /// Reads an identifier escape sequence.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void readIdentifierEscapeSequence() throws CompilerException
	  private void readIdentifierEscapeSequence()
	  {
		readChar();

		if (EOF)
		{
		  throwCompilerException("EOF in escape sequence");
		}
		else if (LineTerminator)
		{
		  throwCompilerException("Line terminator in escape sequence");
		}
		else if (c == 'u')
		{
		  readChar();
		  if (HexadecimalDigit)
		  {
			readHexEscapeSequence(4);
		  }
		  else
		  {
			throwCompilerException("Invalid escape sequence");
		  }
		}
		else
		{
		  throwCompilerException("Invalid escape sequence");
		}
	  }

	  /// <summary>
	  /// Reads an string escape sequence.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void readStringEscapeSequence() throws CompilerException
	  private void readStringEscapeSequence()
	  {
		readChar();

		if (EOF)
		{
		  throwCompilerException("EOF in escape sequence");
		}
		else if (LineTerminator)
		{
		  throwCompilerException("Line terminator in escape sequence");
		}
		else if (c == 'b')
		{
		  c = 0x0008;
		}
		else if (c == 't')
		{
		  c = 0x0009;
		}
		else if (c == 'n')
		{
		  c = 0x000a;
		}
		else if (c == 'v')
		{
		  c = 0x000b;
		}
		else if (c == 'f')
		{
		  c = 0x000c;
		}
		else if (c == 'r')
		{
		  c = 0x000d;
		}
		else if (c == 'u')
		{
		  readChar();
		  if (HexadecimalDigit)
		  {
			readHexEscapeSequence(4);
		  }
		  else
		  {
			unreadChar();
		  }
		}
		else if (c == 'x')
		{
		  readChar();
		  if (HexadecimalDigit)
		  {
			readHexEscapeSequence(2);
		  }
		  else
		  {
			unreadChar();
		  }
		}
		else if (OctalDigit)
		{
		  readOctalEscapeSequence();
		}
		else
		{
		  // other characters escape themselves
		}
	  }

	  /// <summary>
	  /// Reads a hexadecimal escape sequence.
	  /// </summary>
	  /// <param name="count"> number of characters to read </param>
	  /// <exception cref="CompilerException"> if the escape sequence was malformed </exception>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void readHexEscapeSequence(int count) throws CompilerException
	  private void readHexEscapeSequence(int count)
	  {
		int value = char.digit((char) c, BASE_HEXADECIMAL);

		while (--count > 0)
		{
		  readChar();

		  if (!HexadecimalDigit)
		  {
			throwCompilerException("Bad escape sequence");
		  }
		  else
		  {
			value = (value << 4) + char.digit((char) c, BASE_HEXADECIMAL);
		  }
		}

		c = value;
	  }

	  /// <summary>
	  /// Reads an octal escape sequence of up to 3 octal digits.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void readOctalEscapeSequence() throws CompilerException
	  private void readOctalEscapeSequence()
	  {

		int value = char.digit((char) c, BASE_OCTAL);

		readChar();
		if (OctalDigit)
		{
		  value = (value << 3) + char.digit((char) c, BASE_OCTAL);
		  readChar();
		  if (OctalDigit)
		  {
			value = (value << 3) + char.digit((char) c, BASE_OCTAL);
		  }
		  else
		  {
			unreadChar();
		  }
		}
		else
		{
		  unreadChar();
		}

		c = value;
	  }

	  /// <summary>
	  /// Skips a line terminator, updating the current line number.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void skipLineTerminator() throws CompilerException
	  private void skipLineTerminator()
	  {
		// This is not mentioned in the JavaScript specification, but "\r\n" is
		// usually recognised as a single newline and not as two separate newline
		// characters.

		if (c == '\r')
		{
		  readChar();
		  if (c == '\n')
		  {
			readChar();
		  }
		}
		else
		{
		  readChar();
		}

		lineNumber++;
	  }

	  /// <summary>
	  /// Returns the next token from the input.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public Token nextToken() throws CompilerException
	  public virtual Token nextToken()
	  {
		oldPosition = curPosition;

		if (EOF)
		{
		  return Token.EOF_Renamed;
		}
		else if (LineTerminator)
		{
		  return tokenizeLineTerminator();
		}
		else if (Whitespace)
		{
		  return tokenizeWhitespace();
		}
		else if (c == '/')
		{
		  return tokenizeSlash();
		}
		else if (c == '.')
		{
		  return tokenizeNumeric();
		}
		else if (DecimalDigit)
		{
		  return tokenizeNumeric();
		}
		else if (c == '\'' || c == '\"')
		{
		  return tokenizeString();
		}
		else if (IdentifierStart)
		{
		  return tokenizeIdentifier();
		}
		else
		{
		  return tokenizeOperator();
		}
	  }

	  /// <summary>
	  /// Tokenizes a line terminator.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private Token tokenizeLineTerminator() throws CompilerException
	  private Token tokenizeLineTerminator()
	  {
		do
		{
		  skipLineTerminator();
		} while (LineTerminator);

		return Token.NEWLINE;
	  }

	  /// <summary>
	  /// Tokenizes whitespace.
	  /// </summary>
	  private Token tokenizeWhitespace()
	  {
		do
		{
		  readChar();
		} while (Whitespace);

		return Token.WHITESPACE;
	  }

	  /// <summary>
	  /// Tokenizes tokens that start with a forward slash.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private Token tokenizeSlash() throws CompilerException
	  private Token tokenizeSlash()
	  {
		readChar();

		if (c == '/')
		{
		  return tokenizeSingleLineComment();
		}
		else if (c == '*')
		{
		  return tokenizeMultiLineComment();
		}
		else if (c == '=')
		{
		  readChar();
		  return Token.OPERATOR_DIVIDEASSIGNMENT;
		}
		else
		{
		  return Token.OPERATOR_DIVIDE;
		}
	  }

	  /// <summary>
	  /// Tokenizes a single line comment.
	  /// </summary>
	  private Token tokenizeSingleLineComment()
	  {
		do
		{
		  readChar();
		} while (!EOF && !LineTerminator);

		return Token.SINGLELINECOMMENT;
	  }

	  /// <summary>
	  /// Tokenizes a multi line comment.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private Token tokenizeMultiLineComment() throws CompilerException
	  private Token tokenizeMultiLineComment()
	  {
		bool lineTerminator = false;

		readChar();

		while (true)
		{
		  if (EOF)
		  {
			break;
		  }
		  else if (LineTerminator)
		  {
			skipLineTerminator();
			lineTerminator = true;
		  }
		  else if (c == '*')
		  {
			readChar();
			if (c == '/')
			{
			  readChar();
			  break;
			}
		  }
		  else
		  {
			readChar();
		  }
		}

		if (lineTerminator)
		{
		  return Token.MULTILINECOMMENT;
		}
		else
		{
		  return Token.SINGLELINECOMMENT;
		}
	  }

	  /// <summary>
	  /// Tokenizes a numeric literal.
	  /// 
	  /// <para>Older versions of the JavaScript(TM) and ECMAScript specifications
	  /// included support for octal numeric literals.  Although the latest
	  /// version of the the specification (3rd edition, ECMA-262, 3rd December
	  /// 1999) doesn't provide support for them we do for compatibility reasons.
	  /// 
	  /// </para>
	  /// <para>As a special case, numbers that start with "08" or "09" are treated
	  /// as decimal.  Strictly speaking such literals should be interpreted as
	  /// two numeric literals, a zero followed by a decimal whose leading digit
	  /// is 8 or 9.  However two consecutive integers are not legal according to
	  /// the ECMAScript grammar.
	  /// </para>
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private Token tokenizeNumeric() throws CompilerException
	  private Token tokenizeNumeric()
	  {
		int state = TOKENIZENUMERIC_ENTRY_POINT;

		while (true)
		{
		  switch (state)
		  {
			// entry point
			case TOKENIZENUMERIC_ENTRY_POINT:
			  if (c == '.')
			  {
				state = TOKENIZENUMERIC_LEADING_ZERO;
			  }
			  else if (c == '0')
			  {
				state = TOKENIZENUMERIC_LEADING_DECIMAL;
			  }
			  else
			  {
				state = TOKENIZENUMERIC_DECIMAL_LITERAL;
			  }
			  break;

			// leading decimal point
			case TOKENIZENUMERIC_LEADING_ZERO:
			  readChar();
			  if (DecimalDigit)
			  {
				state = TOKENIZENUMERIC_DECIMAL_POINT;
			  }
			  else
			  {
				state = TOKENIZENUMERIC_RETURN_OPERATOR_DOT;
			  }
			  break;

			// leading zero
			case TOKENIZENUMERIC_LEADING_DECIMAL:
			  readChar();
			  if (OctalDigit)
			  {
				state = TOKENIZENUMERIC_OCTAL_LITERAL;
			  }
			  else if (c == 'x' || c == 'X')
			  {
				state = TOKENIZENUMERIC_LEADING_OX;
			  }
			  else if (DecimalDigit)
			  {
				state = TOKENIZENUMERIC_DECIMAL_LITERAL;
			  }
			  else if (c == '.')
			  {
				state = TOKENIZENUMERIC_DECIMAL_POINT;
			  }
			  else if (c == 'e' || c == 'E')
			  {
				state = TOKENIZENUMERIC_EXPONENT_SYMBOL;
			  }
			  else
			  {
				state = TOKENIZENUMERIC_RETURN_DECIMAL;
			  }
			  break;

			// octal literal
			case TOKENIZENUMERIC_OCTAL_LITERAL:
				readChar();
			  if (OctalDigit)
			  {
				// loop
			  }
			  else
			  {
				state = TOKENIZENUMERIC_RETURN_OCTAL;
			  }
			  break;

			// leading '0x' or '0X'
			case TOKENIZENUMERIC_LEADING_OX:
			  readChar();
			  if (HexadecimalDigit)
			  {
				state = TOKENIZENUMERIC_HEXADECIMAL_LITERAL;
			  }
			  else
			  {
				throwCompilerException("Invalid hexadecimal literal");
			  }
			  break;

			// hexadecimal literal
			case TOKENIZENUMERIC_HEXADECIMAL_LITERAL:
			  readChar();
			  if (HexadecimalDigit)
			  {
				// loop
			  }
			  else
			  {
				state = TOKENIZENUMERIC_RETURN_HEXADECIMAL;
			  }
			  break;

			// decimal literal
			case TOKENIZENUMERIC_DECIMAL_LITERAL:
			  readChar();
			  if (DecimalDigit)
			  {
				// loop
			  }
			  else if (c == '.')
			  {
				state = TOKENIZENUMERIC_DECIMAL_POINT;
			  }
			  else if (c == 'e' || c == 'E')
			  {
				state = TOKENIZENUMERIC_EXPONENT_SYMBOL;
			  }
			  else
			  {
				state = TOKENIZENUMERIC_RETURN_DECIMAL;
			  }
			  break;

			// decimal point
			case TOKENIZENUMERIC_DECIMAL_POINT:
			  readChar();
			  if (DecimalDigit)
			  {
				state = TOKENIZENUMERIC_FRACTIONAL_PART;
			  }
			  else if (c == 'e' || c == 'E')
			  {
				state = TOKENIZENUMERIC_EXPONENT_SYMBOL;
			  }
			  else
			  {
				state = TOKENIZENUMERIC_RETURN_FLOAT;
			  }
			  break;

			// fractional part
			case TOKENIZENUMERIC_FRACTIONAL_PART:
			  readChar();
			  if (DecimalDigit)
			  {
				// loop
			  }
			  else if (c == 'e' || c == 'E')
			  {
				state = TOKENIZENUMERIC_EXPONENT_SYMBOL;
			  }
			  else
			  {
				state = TOKENIZENUMERIC_RETURN_FLOAT;
			  }
			  break;

			// exponent symbol
			case TOKENIZENUMERIC_EXPONENT_SYMBOL:
			  readChar();
			  if (c == '+' || c == '-')
			  {
				state = TOKENIZENUMERIC_EXPONENT_SIGN;
			  }
			  else if (DecimalDigit)
			  {
				state = TOKENIZENUMERIC_EXPONENT_PART;
			  }
			  else
			  {
				state = TOKENIZENUMERIC_UNREAD_ONE;
			  }
			  break;

			// exponent sign
			case TOKENIZENUMERIC_EXPONENT_SIGN:
			  readChar();
			  if (DecimalDigit)
			  {
				state = TOKENIZENUMERIC_EXPONENT_PART;
			  }
			  else
			  {
				state = TOKENIZENUMERIC_UNREAD_TWO;
			  }
			  break;

			// exponent part
			case TOKENIZENUMERIC_EXPONENT_PART:
			  readChar();
			  if (DecimalDigit)
			  {
				// loop
			  }
			  else
			  {
				state = TOKENIZENUMERIC_RETURN_FLOAT;
			  }
			  break;

			// unread two characters
			case TOKENIZENUMERIC_UNREAD_TWO:
			  unreadChar();
			  state = TOKENIZENUMERIC_UNREAD_ONE;
			  break;

			// unread one character
			case TOKENIZENUMERIC_UNREAD_ONE:
			  unreadChar();
			  state = TOKENIZENUMERIC_RETURN_FLOAT;
			  break;

			// floating literal
			case TOKENIZENUMERIC_RETURN_FLOAT:
			  return new Token(Token.TYPE_FLOAT, input.Substring(oldPosition, curPosition - oldPosition));

			// decimal literal
			case TOKENIZENUMERIC_RETURN_DECIMAL:
			  return new Token(Token.TYPE_DECIMAL, input.Substring(oldPosition, curPosition - oldPosition));

			// octal literal
			case TOKENIZENUMERIC_RETURN_OCTAL:
			  return new Token(Token.TYPE_OCTAL, input.Substring(oldPosition, curPosition - oldPosition));

			// hexadecimal literal
			case TOKENIZENUMERIC_RETURN_HEXADECIMAL:
			  return new Token(Token.TYPE_HEXADECIMAL, input.Substring(oldPosition, curPosition - oldPosition));

			// '.' operator
			case TOKENIZENUMERIC_RETURN_OPERATOR_DOT:
			  return Token.OPERATOR_DOT;
		  }
		}
	  }

	  /// <summary>
	  /// Tokenizes a ECMAScript string.  The current character is used as the
	  /// quote character.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private Token tokenizeString() throws CompilerException
	  private Token tokenizeString()
	  {
		StringBuilder buffer = new StringBuilder();
		int quote = c;

		// skip the leading quote
		readChar();

		while (true)
		{
		  if (c == quote)
		  {
			break;
		  }
		  else if (EOF)
		  {
			throwCompilerException("EOF in string literal");
		  }
		  else if (LineTerminator)
		  {
			throwCompilerException("Line terminator in string literal");
		  }
		  else if (c == '\\')
		  {
			readStringEscapeSequence();
			buffer.Append((char) c);
		  }
		  else
		  {
			buffer.Append((char) c);
		  }

		  readChar();
		}

		// skip the trailing quote
		readChar();

		return new Token(Token.TYPE_STRING, buffer.ToString());
	  }

	  /// <summary>
	  /// Tokenizes a ECMAScript identifier.  On entry the current character must
	  /// be a valid identifier start character.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private Token tokenizeIdentifier() throws CompilerException
	  private Token tokenizeIdentifier()
	  {
		StringBuilder buffer = new StringBuilder();

		// identifier start

		buffer.Append((char) c);
		readChar();

		// identifier part

		while (true)
		{
		  if (IdentifierPart)
		  {
			buffer.Append((char) c);
		  }
		  else if (c == '\\')
		  {
			readIdentifierEscapeSequence();
			if (IdentifierPart)
			{
			  buffer.Append((char) c);
			}
			else
			{
			  throwCompilerException("Invalid escaped character in identifier");
			}
		  }
		  else
		  {
			break;
		  }

		  readChar();
		}

		// If this identifier matches a keyword we need to return that keyword
		// token.

		Token token = (Token) keywords[buffer.ToString()];

		if (token != null)
		{
		  return token;
		}
		else
		{
		  return new Token(Token.TYPE_IDENTIFIER, buffer.ToString());
		}
	  }

	  /// <summary>
	  /// Tokenizes an operator.
	  /// </summary>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private Token tokenizeOperator() throws CompilerException
	  private Token tokenizeOperator()
	  {
		// TODO
		//   * analyse a suitable JavaScript corpus (Mozilla tests?) and order
		//     these tests in descending order of frequency.
		//   * consider using a switch statement for the first operator character.

		if (c == ';')
		{
		  readChar();
		  return Token.OPERATOR_SEMICOLON;

		}
		else if (c == ',')
		{
		  readChar();
		  return Token.OPERATOR_COMMA;

		}
		else if (c == '(')
		{
		  readChar();
		  return Token.OPERATOR_OPENPAREN;

		}
		else if (c == ')')
		{
		  readChar();
		  return Token.OPERATOR_CLOSEPAREN;

		}
		else if (c == '{')
		{
		  readChar();
		  return Token.OPERATOR_OPENBRACE;

		}
		else if (c == '}')
		{
		  readChar();
		  return Token.OPERATOR_CLOSEBRACE;

		}
		else if (c == '[')
		{
		  readChar();
		  return Token.OPERATOR_OPENSQUARE;

		}
		else if (c == ']')
		{
		  readChar();
		  return Token.OPERATOR_CLOSESQUARE;

		}
		else if (c == '?')
		{
		  readChar();
		  return Token.OPERATOR_CONDITIONAL;

		}
		else if (c == ':')
		{
		  readChar();
		  return Token.OPERATOR_COLON;

		}
		else if (c == '+')
		{
		  readChar();
		  if (c == '+')
		  {
			readChar();
			return Token.OPERATOR_PLUSPLUS;
		  }
		  else if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_PLUSASSIGNMENT;
		  }
		  else
		  {
			return Token.OPERATOR_PLUS;
		  }

		}
		else if (c == '-')
		{
		  readChar();
		  if (c == '-')
		  {
			readChar();
			return Token.OPERATOR_MINUSMINUS;
		  }
		  else if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_MINUSASSIGNMENT;
		  }
		  else
		  {
			return Token.OPERATOR_MINUS;
		  }

		}
		else if (c == '*')
		{
		  readChar();
		  if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_MULTIPLYASSIGNMENT;
		  }
		  else
		  {
			return Token.OPERATOR_MULTIPLY;
		  }

		}
		else if (c == '%')
		{
		  readChar();
		  if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_MODULOASSIGNMENT;
		  }
		  else
		  {
			return Token.OPERATOR_MODULO;
		  }

		}
		else if (c == '=')
		{
		  readChar();
		  if (c == '=')
		  {
			readChar();
			if (c == '=')
			{
			  readChar();
			  return Token.OPERATOR_EQUALEQUALEQUAL;
			}
			else
			{
			  return Token.OPERATOR_EQUALEQUAL;
			}
		  }
		  else
		  {
			return Token.OPERATOR_ASSIGNMENT;
		  }

		}
		else if (c == '!')
		{
		  readChar();
		  if (c == '=')
		  {
			readChar();
			if (c == '=')
			{
			  readChar();
			  return Token.OPERATOR_NOTEQUALEQUAL;
			}
			else
			{
			  return Token.OPERATOR_NOTEQUAL;
			}
		  }
		  else
		  {
			return Token.OPERATOR_LOGICALNOT;
		  }

		}
		else if (c == '&')
		{
		  readChar();
		  if (c == '&')
		  {
			readChar();
			return Token.OPERATOR_LOGICALAND;
		  }
		  else if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_BITWISEANDASSIGNMENT;
		  }
		  else
		  {
			return Token.OPERATOR_BITWISEAND;
		  }

		}
		else if (c == '|')
		{
		  readChar();
		  if (c == '|')
		  {
			readChar();
			return Token.OPERATOR_LOGICALOR;
		  }
		  else if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_BITWISEORASSIGNMENT;
		  }
		  else
		  {
			return Token.OPERATOR_BITWISEOR;
		  }

		}
		else if (c == '^')
		{
		  readChar();
		  if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_BITWISEXORASSIGNMENT;
		  }
		  else
		  {
			return Token.OPERATOR_BITWISEXOR;
		  }

		}
		else if (c == '~')
		{
		  readChar();
		  return Token.OPERATOR_BITWISENOT;

		}
		else if (c == '<')
		{
		  readChar();
		  if (c == '<')
		  {
			readChar();
			if (c == '=')
			{
			  readChar();
			  return Token.OPERATOR_SHIFTLEFTASSIGNMENT;
			}
			else
			{
			  return Token.OPERATOR_SHIFTLEFT;
			}
		  }
		  else if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_LESSTHANOREQUAL;
		  }
		  else
		  {
			return Token.OPERATOR_LESSTHAN;
		  }

		}
		else if (c == '>')
		{
		  readChar();
		  if (c == '>')
		  {
			readChar();
			if (c == '>')
			{
			  readChar();
			  if (c == '=')
			  {
				readChar();
				return Token.OPERATOR_SHIFTRIGHTUNSIGNEDASSIGNMENT;
			  }
			  else
			  {
				return Token.OPERATOR_SHIFTRIGHTUNSIGNED;
			  }
			}
			else if (c == '=')
			{
			  readChar();
			  return Token.OPERATOR_SHIFTRIGHTASSIGNMENT;
			}
			else
			{
			  return Token.OPERATOR_SHIFTRIGHT;
			}
		  }
		  else if (c == '=')
		  {
			readChar();
			return Token.OPERATOR_GREATERTHANOREQUAL;
		  }
		  else
		  {
			return Token.OPERATOR_GREATERTHAN;
		  }

		}
		else if (c == '\\')
		{
		  // Although not an operator we check for this symbol last since its
		  // probably the least likely input.  A '\' indicates an identifier that
		  // starts with an escaped character.

		  readIdentifierEscapeSequence();
		  if (IdentifierStart)
		  {
			return tokenizeIdentifier();
		  }
		  else
		  {
			throwCompilerException("Invalid escaped character in identifier");
		  }
		}

		// Give up.
		return tokenizeUnknown();
	  }

	  /// <summary>
	  /// Tokenizes an unknown character.
	  /// </summary>
	  private Token tokenizeUnknown()
	  {
		readChar();

		return new Token(Token.TYPE_UNKNOWN, input.Substring(oldPosition, curPosition - oldPosition));
	  }

	  /// <summary>
	  /// Throws a new CompilerException with the given message.  This method will
	  /// never normally return.
	  /// </summary>
	  /// <exception cref="CompilerException"> </exception>
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void throwCompilerException(String message) throws CompilerException
	  private void throwCompilerException(string message)
	  {
		throw new CompilerException(message, LineNumber);
	  }
	}

}