// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor.combinator
{

	using BooleanLiteral = com.google.minijoe.compiler.ast.BooleanLiteral;
	using Expression = com.google.minijoe.compiler.ast.Expression;
	using LogicalAndExpression = com.google.minijoe.compiler.ast.LogicalAndExpression;
	using LogicalOrExpression = com.google.minijoe.compiler.ast.LogicalOrExpression;

	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public class AlgebraicIdentityVisitor : IdentityVisitor
	{
	  // Currently disabled, to avoid problems with expressions
	  // like hello " + (1 * "World".
	  //  
	  // public Expression visit(BinaryOperatorExpression boe) {
	  //   Token op = boe.operator;
	  //
	  //   if (boe.leftExpression instanceof NumberLiteral
	  //       && boe.rightExpression instanceof NumberLiteral) {      
	  //     double leftValue = ((NumberLiteral) boe.leftExpression).value;
	  //     double rightValue = ((NumberLiteral) boe.rightExpression).value;
	  //
	  //     if ((op == Token.OPERATOR_PLUS && leftValue == 0.0)
	  //         || (op == Token.OPERATOR_MULTIPLY && leftValue == 1.0)) {
	  //       return boe.rightExpression;
	  //     }
	  //
	  //     if((op == Token.OPERATOR_PLUS && rightValue == 0.0)
	  //         || (op == Token.OPERATOR_MULTIPLY && rightValue == 1.0)
	  //         || (op == Token.OPERATOR_DIVIDE && rightValue == 1.0))
	  //       return boe.leftExpression;
	  //   }
	  //
	  //   return boe;
	  // }

	  public override Expression visit(LogicalAndExpression expression)
	  {
		if (expression.leftExpression is BooleanLiteral)
		{
		  if (((BooleanLiteral) expression.leftExpression).value == false)
		  {
			return expression.leftExpression;
		  }
		  else if (((BooleanLiteral) expression.leftExpression).value == true)
		  {
			return expression.rightExpression;
		  }
		}

		if (expression.rightExpression is BooleanLiteral)
		{
		  if (((BooleanLiteral) expression.rightExpression).value == false)
		  {
			return expression.rightExpression;
		  }
		  else if (((BooleanLiteral) expression.rightExpression).value == true)
		  {
			return expression.leftExpression;
		  }
		}

		return expression;
	  }

	  public override Expression visit(LogicalOrExpression expression)
	  {
		if (expression.leftExpression is BooleanLiteral)
		{
		  if (((BooleanLiteral) expression.leftExpression).value == true)
		  {
			return expression.leftExpression;
		  }
		  else if (((BooleanLiteral) expression.leftExpression).value == false)
		  {
			return expression.rightExpression;
		  }
		}

		if (expression.rightExpression is BooleanLiteral)
		{
		  if (((BooleanLiteral) expression.rightExpression).value == true)
		  {
			return expression.rightExpression;
		  }
		  else if (((BooleanLiteral) expression.rightExpression).value == false)
		  {
			return expression.leftExpression;
		  }
		}

		return expression;
	  }
	}

}