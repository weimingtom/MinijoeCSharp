// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor
{

	using ArrayLiteral = com.google.minijoe.compiler.ast.ArrayLiteral;
	using AssignmentExpression = com.google.minijoe.compiler.ast.AssignmentExpression;
	using AssignmentOperatorExpression = com.google.minijoe.compiler.ast.AssignmentOperatorExpression;
	using BinaryOperatorExpression = com.google.minijoe.compiler.ast.BinaryOperatorExpression;
	using BlockStatement = com.google.minijoe.compiler.ast.BlockStatement;
	using BooleanLiteral = com.google.minijoe.compiler.ast.BooleanLiteral;
	using BreakStatement = com.google.minijoe.compiler.ast.BreakStatement;
	using CallExpression = com.google.minijoe.compiler.ast.CallExpression;
	using CaseStatement = com.google.minijoe.compiler.ast.CaseStatement;
	using ConditionalExpression = com.google.minijoe.compiler.ast.ConditionalExpression;
	using ContinueStatement = com.google.minijoe.compiler.ast.ContinueStatement;
	using DeleteExpression = com.google.minijoe.compiler.ast.DeleteExpression;
	using DoStatement = com.google.minijoe.compiler.ast.DoStatement;
	using EmptyStatement = com.google.minijoe.compiler.ast.EmptyStatement;
	using Expression = com.google.minijoe.compiler.ast.Expression;
	using ExpressionStatement = com.google.minijoe.compiler.ast.ExpressionStatement;
	using ForInStatement = com.google.minijoe.compiler.ast.ForInStatement;
	using ForStatement = com.google.minijoe.compiler.ast.ForStatement;
	using FunctionDeclaration = com.google.minijoe.compiler.ast.FunctionDeclaration;
	using FunctionLiteral = com.google.minijoe.compiler.ast.FunctionLiteral;
	using Identifier = com.google.minijoe.compiler.ast.Identifier;
	using IfStatement = com.google.minijoe.compiler.ast.IfStatement;
	using IncrementExpression = com.google.minijoe.compiler.ast.IncrementExpression;
	using LabelledStatement = com.google.minijoe.compiler.ast.LabelledStatement;
	using LogicalAndExpression = com.google.minijoe.compiler.ast.LogicalAndExpression;
	using LogicalOrExpression = com.google.minijoe.compiler.ast.LogicalOrExpression;
	using NewExpression = com.google.minijoe.compiler.ast.NewExpression;
	using NullLiteral = com.google.minijoe.compiler.ast.NullLiteral;
	using NumberLiteral = com.google.minijoe.compiler.ast.NumberLiteral;
	using ObjectLiteral = com.google.minijoe.compiler.ast.ObjectLiteral;
	using ObjectLiteralProperty = com.google.minijoe.compiler.ast.ObjectLiteralProperty;
	using Program = com.google.minijoe.compiler.ast.Program;
	using PropertyExpression = com.google.minijoe.compiler.ast.PropertyExpression;
	using ReturnStatement = com.google.minijoe.compiler.ast.ReturnStatement;
	using Statement = com.google.minijoe.compiler.ast.Statement;
	using StringLiteral = com.google.minijoe.compiler.ast.StringLiteral;
	using SwitchStatement = com.google.minijoe.compiler.ast.SwitchStatement;
	using ThisLiteral = com.google.minijoe.compiler.ast.ThisLiteral;
	using ThrowStatement = com.google.minijoe.compiler.ast.ThrowStatement;
	using TryStatement = com.google.minijoe.compiler.ast.TryStatement;
	using UnaryOperatorExpression = com.google.minijoe.compiler.ast.UnaryOperatorExpression;
	using VariableDeclaration = com.google.minijoe.compiler.ast.VariableDeclaration;
	using VariableExpression = com.google.minijoe.compiler.ast.VariableExpression;
	using VariableStatement = com.google.minijoe.compiler.ast.VariableStatement;
	using WhileStatement = com.google.minijoe.compiler.ast.WhileStatement;
	using WithStatement = com.google.minijoe.compiler.ast.WithStatement;


	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public class RoundtripVisitor : Visitor
	{
	  internal Writer w;
	  internal int indent = 0;

	  public RoundtripVisitor(Writer w)
	  {
		this.w = w;
	  }

	  //
	  // utilities
	  //

	  private void increaseIndent()
	  {
		indent += 2;
	  }

	  private void decreaseIndent()
	  {
		indent -= 2;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void visitStatementArray(com.google.minijoe.compiler.ast.Statement[] statements) throws com.google.minijoe.compiler.CompilerException
	  private void visitStatementArray(Statement[] statements)
	  {
		if (statements != null)
		{
		  for (int i = 0; i < statements.Length; i++)
		  {
			visitStatement(statements[i]);
		  }
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void visitStatement(com.google.minijoe.compiler.ast.Statement statement) throws com.google.minijoe.compiler.CompilerException
	  private void visitStatement(Statement statement)
	  {
		if (statement != null)
		{
		  statement.visitStatement(this);
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void visitExpression(com.google.minijoe.compiler.ast.Expression expression) throws com.google.minijoe.compiler.CompilerException
	  private void visitExpression(Expression expression)
	  {
		if (expression != null)
		{
		  expression.visitExpression(this);
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void write(String string) throws com.google.minijoe.compiler.CompilerException
	  private void write(string @string)
	  {
		try
		{
		  w.write(@string);
		}
		catch (IOException e)
		{
		  throw new CompilerException(e);
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void write(char c) throws com.google.minijoe.compiler.CompilerException
	  private void write(char c)
	  {
		try
		{
		  w.write(c);
		}
		catch (IOException e)
		{
		  throw new CompilerException(e);
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: private void writeIndent() throws com.google.minijoe.compiler.CompilerException
	  private void writeIndent()
	  {
		try
		{
		  w.write('\n');
		  for (int i = 0; i < indent; i++)
		  {
			w.write(' ');
		  }
		}
		catch (IOException e)
		{
		  throw new CompilerException(e);
		}
	  }

	  //
	  // nodes
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Program visit(com.google.minijoe.compiler.ast.Program program) throws com.google.minijoe.compiler.CompilerException
	  public virtual Program visit(Program program)
	  {
		visitStatementArray(program.statements);
		write("\n\n");
		return program;
	  }

	  //
	  // statements
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.FunctionDeclaration declaration) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(FunctionDeclaration declaration)
	  {
		writeIndent();
		declaration.literal.visitExpression(this);
		write(';');
		return declaration;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.BlockStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(BlockStatement statement)
	  {
		writeIndent();
		write('{');
		increaseIndent();
		visitStatementArray(statement.statements);
		decreaseIndent();
		writeIndent();
		write('}');
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.BreakStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(BreakStatement statement)
	  {
		writeIndent();
		if (statement.identifier != null)
		{
		  write("break " + statement.identifier + ";");
		}
		else
		{
		  write("break");
		}
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.CaseStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(CaseStatement statement)
	  {
		writeIndent();
		if (statement.expression == null)
		{
		  write("default:");
		}
		else
		{
		  write("case ");
		  statement.expression.visitExpression(this);
		  write(": ");
		}
		visitStatementArray(statement.statements);
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ContinueStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ContinueStatement statement)
	  {
		writeIndent();
		if (statement.identifier != null)
		{
		  write("continue " + statement.identifier + ";");
		}
		else
		{
		  write("continue;");
		}
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.DoStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(DoStatement statement)
	  {
		writeIndent();
		write("do ");
		increaseIndent();
		statement.statement.visitStatement(this);
		decreaseIndent();
		writeIndent();
		write("while (");
		statement.expression.visitExpression(this);
		write(')');
		return statement;
	  }

	  public virtual Statement visit(EmptyStatement statement)
	  {
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ExpressionStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ExpressionStatement statement)
	  {
		writeIndent();
		statement.expression.visitExpression(this);
		write(';');
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ForStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ForStatement statement)
	  {
		writeIndent();
		write("for (");
		visitExpression(statement.initial);
		write("; ");
		visitExpression(statement.condition);
		write("; ");
		visitExpression(statement.increment);
		write(")");
		increaseIndent();
		statement.statement.visitStatement(this);
		decreaseIndent();
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ForInStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ForInStatement statement)
	  {
		writeIndent();
		write("for (");
		statement.variable.visitExpression(this);
		write(" in ");
		statement.expression.visitExpression(this);
		write(")");
		statement.statement.visitStatement(this);
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.IfStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(IfStatement statement)
	  {
		writeIndent();
		write("if (");
		statement.expression.visitExpression(this);
		write(") ");
		statement.trueStatement.visitStatement(this);
		if (statement.falseStatement != null)
		{
		  writeIndent();
		  write("else ");
		  statement.falseStatement.visitStatement(this);
		}
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.LabelledStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(LabelledStatement statement)
	  {
		writeIndent();
		statement.identifier.visitExpression(this);
		write(": ");
		statement.statement.visitStatement(this);
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ReturnStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ReturnStatement statement)
	  {
		writeIndent();
		if (statement.expression != null)
		{
		  write("return ");
		  statement.expression.visitExpression(this);
		  write(";");
		}
		else
		{
		  write("return;");
		}
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.SwitchStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(SwitchStatement statement)
	  {
		write("switch (");
		statement.expression.visitExpression(this);
		write(") {");
		visitStatementArray(statement.clauses);
		write("}");
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ThrowStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ThrowStatement statement)
	  {
		writeIndent();
		return null;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.TryStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(TryStatement statement)
	  {
		writeIndent();
		write("try");
		statement.tryBlock.visitStatement(this);
		if (statement.catchBlock != null)
		{
		  writeIndent();
		  write("catch (");
		  statement.catchIdentifier.visitExpression(this);
		  write(")");
		  statement.catchBlock.visitStatement(this);
		}
		if (statement.finallyBlock != null)
		{
		  writeIndent();
		  write("finally ");
		  statement.finallyBlock.visitStatement(this);
		}
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.VariableStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(VariableStatement statement)
	  {
		for (int i = 0; i < statement.declarations.Length; i++)
		{
		  statement.declarations[i].visitExpression(this);
		}
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.WhileStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(WhileStatement statement)
	  {
		writeIndent();
		write("while (");
		statement.expression.visitExpression(this);
		write(")");
		statement.statement.visitStatement(this);
		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.WithStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(WithStatement statement)
	  {
		writeIndent();
		write("width (");
		statement.expression.visitExpression(this);
		write(")");
		statement.statement.visitStatement(this);
		return statement;
	  }

	  //
	  // expressions
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.AssignmentExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(AssignmentExpression expression)
	  {
		expression.leftExpression.visitExpression(this);
		write(" = ");
		expression.rightExpression.visitExpression(this);
		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.AssignmentOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(AssignmentOperatorExpression expression)
	  {
		expression.leftExpression.visitExpression(this);
		write(' ');
		write(expression.type.Value);
		write(' ');
		expression.rightExpression.visitExpression(this);
		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.BinaryOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(BinaryOperatorExpression expression)
	  {
		write('(');
		expression.leftExpression.visitExpression(this);
		write(' ');
		write(expression.@operator.Value);
		write(' ');
		expression.rightExpression.visitExpression(this);
		write(')');

		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.CallExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(CallExpression expression)
	  {
		expression.function.visitExpression(this);
		write('(');
		for (int i = 0; i < expression.arguments.Length; i++)
		{
		  if (i > 0)
		  {
			write(", ");
		  }
		  expression.arguments[i].visitExpression(this);
		}
		write(')');
		return null;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ConditionalExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ConditionalExpression expression)
	  {
		write("(");
		expression.expression.visitExpression(this);
		write(" ? ");
		expression.trueExpression.visitExpression(this);
		write(" : ");
		expression.falseExpression.visitExpression(this);
		write(")");
		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.DeleteExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(DeleteExpression expression)
	  {
		write("delete ");
		expression.subExpression.visitExpression(this);
		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.IncrementExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(IncrementExpression expression)
	  {
		if (expression.post)
		{
		  expression.subExpression.visitExpression(this);
		}
		switch (expression.value)
		{
		  case -1:
			write("--");
			break;
		  case 1:
			write("++");
			break;
		  default:
			throw new System.ArgumentException();
		}
		if (!expression.post)
		{
		  expression.subExpression.visitExpression(this);
		}
		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.LogicalAndExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(LogicalAndExpression expression)
	  {
		write('(');
		expression.leftExpression.visitExpression(this);
		write(" && ");
		expression.rightExpression.visitExpression(this);
		write(')');

		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.LogicalOrExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(LogicalOrExpression expression)
	  {
		write('(');
		expression.leftExpression.visitExpression(this);
		write(" && ");
		expression.rightExpression.visitExpression(this);
		write(')');

		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NewExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NewExpression expression)
	  {
		write("new ");
		expression.function.visitExpression(this);
		write("( ");
		for (int i = 0; i < expression.arguments.Length; i++)
		{
		  if (i != 0)
		  {
			write(", ");
		  }
		}
		write(")");
		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.PropertyExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(PropertyExpression expression)
	  {
		expression.leftExpression.visitExpression(this);
		write("[");
		expression.rightExpression.visitExpression(this);
		write("]");
		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.UnaryOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(UnaryOperatorExpression expression)
	  {
		write('(');
		write(expression.@operator.Value);
		write(' ');
		expression.subExpression.visitExpression(this);
		write(')');

		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.VariableExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(VariableExpression expression)
	  {
		write("var ");

		for (int i = 0; i < expression.declarations.Length; i++)
		{
		  if (i != 0)
		  {
			write(", ");
		  }
		  expression.declarations[i].visitExpression(this);
		}

		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.VariableDeclaration declaration) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(VariableDeclaration declaration)
	  {
		declaration.identifier.visitExpression(this);
		if (declaration.initializer != null)
		{
		  write(" = ");
		  declaration.initializer.visitExpression(this);
		}
		return declaration;
	  }

	  //
	  // literals
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.Identifier identifier) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(Identifier identifier)
	  {
		write(identifier.@string);
		return identifier;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ThisLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ThisLiteral literal)
	  {
		write("this");
		return literal;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NullLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NullLiteral literal)
	  {
		write("null");
		return literal;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.BooleanLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(BooleanLiteral literal)
	  {
		write("" + literal.value);
		return literal;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NumberLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NumberLiteral literal)
	  {
		write("" + literal.value);
		return literal;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.StringLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(StringLiteral literal)
	  {
		write("\"" + literal.@string + "\"");
		return literal;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ArrayLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ArrayLiteral literal)
	  {
		write("[");
		for (int i = 0; i < literal.elements.Length; i++)
		{
		  if (i != 0)
		  {
			write(", ");
		  }
		  if (literal.elements[i] != null)
		  {
			literal.elements[i].visitExpression(this);
		  }
		}
		return null;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.FunctionLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(FunctionLiteral literal)
	  {
		write("function ");
		if (literal.name != null)
		{
		  literal.name.visitExpression(this);
		}
		write('(');
		for (int i = 0; i < literal.parameters.Length; i++)
		{
		  if (i > 0)
		  {
			write(", ");
		  }
		  literal.parameters[i].visitExpression(this);
		}
		write(") {");
		increaseIndent();
		visitStatementArray(literal.statements);
		decreaseIndent();
		writeIndent();
		write("}");

		return literal;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ObjectLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ObjectLiteral literal)
	  {
		write("{");
		for (int i = 0; i < literal.properties.Length; i++)
		{
		  if (i > 0)
		  {
			write(", ");
		  }
		  literal.properties[i].visitExpression(this);
		}
		write("}");
		return literal;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ObjectLiteralProperty property) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ObjectLiteralProperty property)
	  {
		property.name.visitExpression(this);
		write(": ");
		property.value.visitExpression(this);
		return property;
	  }
	}

}