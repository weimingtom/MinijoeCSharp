using System.Collections;

// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor
{

	using AssignmentExpression = com.google.minijoe.compiler.ast.AssignmentExpression;
	using BinaryOperatorExpression = com.google.minijoe.compiler.ast.BinaryOperatorExpression;
	using BlockStatement = com.google.minijoe.compiler.ast.BlockStatement;
	using EmptyStatement = com.google.minijoe.compiler.ast.EmptyStatement;
	using Expression = com.google.minijoe.compiler.ast.Expression;
	using ExpressionStatement = com.google.minijoe.compiler.ast.ExpressionStatement;
	using FunctionDeclaration = com.google.minijoe.compiler.ast.FunctionDeclaration;
	using FunctionLiteral = com.google.minijoe.compiler.ast.FunctionLiteral;
	using Identifier = com.google.minijoe.compiler.ast.Identifier;
	using Program = com.google.minijoe.compiler.ast.Program;
	using Statement = com.google.minijoe.compiler.ast.Statement;
	using VariableDeclaration = com.google.minijoe.compiler.ast.VariableDeclaration;
	using VariableExpression = com.google.minijoe.compiler.ast.VariableExpression;
	using VariableStatement = com.google.minijoe.compiler.ast.VariableStatement;
	using WithStatement = com.google.minijoe.compiler.ast.WithStatement;

	/// <summary>
	/// Process function and variable declarations.
	/// 
	/// @author Andy Hayward
	/// </summary>
	public class DeclarationVisitor : TraversalVisitor
	{
	  private ArrayList functionVector;
	  private ArrayList variableVector;
	  private bool hasWithStatement = false;
	  private bool hasArgumentsVariable = false;
	  private bool hasFunctionLiteral = false;

	  public DeclarationVisitor() : base()
	  {
		visitor = this;
	  }

	  private void addVariable(Identifier identifier)
	  {
		if (variableVector.IndexOf(identifier) == -1)
		{
		  identifier.index = variableVector.Count;
		  variableVector.Add(identifier);
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Program visit(com.google.minijoe.compiler.ast.Program program) throws com.google.minijoe.compiler.CompilerException
	  public override Program visit(Program program)
	  {
		ArrayList oldFunctionVector = functionVector;

		functionVector = new ArrayList();

		program = base.visit(program);

		program.functions = Util.vectorToStatementArray(functionVector);

		functionVector = oldFunctionVector;

		return program;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.FunctionLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public override Expression visit(FunctionLiteral literal)
	  {
		ArrayList oldFunctionVector = functionVector;
		ArrayList oldVariableVector = variableVector;
		bool oldHasWithStatement = hasWithStatement;
		bool oldHasArgumentsVariable = hasArgumentsVariable;

		functionVector = new ArrayList();
		variableVector = new ArrayList();
		hasWithStatement = false;
		hasArgumentsVariable = false;
		hasFunctionLiteral = false;

		Identifier[] parameters = literal.parameters;
		for (int i = 0; i < parameters.Length; i++)
		{
		  addVariable(parameters[i]);
		}

		literal = (FunctionLiteral) base.visit(literal);

		literal.functions = Util.vectorToStatementArray(functionVector);
		literal.variables = Util.vectorToIdentifierArray(variableVector);

		// if this function literal:
		// * contains a function literal
		// * contains a 'with' statement
		// * contains a reference to 'arguments'
		//
		// then we need to disable the "access locals by index" optimisation for
		// this function literal.

		literal.enableLocalsOptimization = !(hasWithStatement | hasArgumentsVariable | hasFunctionLiteral);

		functionVector = oldFunctionVector;
		variableVector = oldVariableVector;
		hasWithStatement = oldHasWithStatement;
		hasArgumentsVariable = oldHasArgumentsVariable;
		hasFunctionLiteral = true;

		return literal;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.FunctionDeclaration functionDeclaration) throws com.google.minijoe.compiler.CompilerException
	  public override Statement visit(FunctionDeclaration functionDeclaration)
	  {
		functionDeclaration = (FunctionDeclaration) base.visit(functionDeclaration);

		functionVector.Add(new ExpressionStatement(functionDeclaration.literal));

		return new EmptyStatement();
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.WithStatement withStatement) throws com.google.minijoe.compiler.CompilerException
	  public override Statement visit(WithStatement withStatement)
	  {
		withStatement = (WithStatement) base.visit(withStatement);

		hasWithStatement = true;

		return withStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.VariableStatement variableStatement) throws com.google.minijoe.compiler.CompilerException
	  public override Statement visit(VariableStatement variableStatement)
	  {
		ArrayList statements = new ArrayList(0);

		for (int i = 0; i < variableStatement.declarations.Length; i++)
		{
		  Expression expression = visitExpression(variableStatement.declarations[i]);

		  if (expression != null)
		  {
			Statement statement = new ExpressionStatement(expression);
			statement.LineNumber = variableStatement.LineNumber;
			statements.Add(statement);
		  }
		}

		if (statements.Count == 0)
		{
		  return new EmptyStatement();
		}
		else if (statements.Count == 1)
		{
		  return (ExpressionStatement) statements[0];
		}
		else
		{
		  return new BlockStatement(Util.vectorToStatementArray(statements));
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.VariableExpression variableExpression) throws com.google.minijoe.compiler.CompilerException
	  public override Expression visit(VariableExpression variableExpression)
	  {
		Expression result = null;

		for (int i = 0; i < variableExpression.declarations.Length; i++)
		{
		  Expression expression = visitExpression(variableExpression.declarations[i]);

		  if (expression != null)
		  {
			if (result == null)
			{
			  result = expression;
			}
			else
			{
			  result = new BinaryOperatorExpression(result, expression, Token.OPERATOR_COMMA);
			}
		  }
		}

		return result;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.VariableDeclaration declaration) throws com.google.minijoe.compiler.CompilerException
	  public override Expression visit(VariableDeclaration declaration)
	  {
		Identifier identifier = visitIdentifier(declaration.identifier);
		Expression initializer = visitExpression(declaration.initializer);
		Expression result = null;

		if (variableVector != null)
		{
		  addVariable(identifier);
		}

		if (initializer != null)
		{
		  result = new AssignmentExpression(identifier, initializer);
		}
		else
		{
		  result = identifier;
		}

		return result;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.Identifier identifier) throws com.google.minijoe.compiler.CompilerException
	  public override Expression visit(Identifier identifier)
	  {
		identifier = (Identifier) base.visit(identifier);

		if (identifier.@string.Equals("arguments"))
		{
		  hasArgumentsVariable = true;
		}

		return identifier;
	  }
	}

}