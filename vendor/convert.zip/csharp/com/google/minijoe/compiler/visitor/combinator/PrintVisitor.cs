using System;

// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor.combinator
{

	using ArrayLiteral = com.google.minijoe.compiler.ast.ArrayLiteral;
	using AssignmentExpression = com.google.minijoe.compiler.ast.AssignmentExpression;
	using AssignmentOperatorExpression = com.google.minijoe.compiler.ast.AssignmentOperatorExpression;
	using BinaryOperatorExpression = com.google.minijoe.compiler.ast.BinaryOperatorExpression;
	using BlockStatement = com.google.minijoe.compiler.ast.BlockStatement;
	using BooleanLiteral = com.google.minijoe.compiler.ast.BooleanLiteral;
	using BreakStatement = com.google.minijoe.compiler.ast.BreakStatement;
	using CallExpression = com.google.minijoe.compiler.ast.CallExpression;
	using CaseStatement = com.google.minijoe.compiler.ast.CaseStatement;
	using ConditionalExpression = com.google.minijoe.compiler.ast.ConditionalExpression;
	using ContinueStatement = com.google.minijoe.compiler.ast.ContinueStatement;
	using DeleteExpression = com.google.minijoe.compiler.ast.DeleteExpression;
	using DoStatement = com.google.minijoe.compiler.ast.DoStatement;
	using EmptyStatement = com.google.minijoe.compiler.ast.EmptyStatement;
	using Expression = com.google.minijoe.compiler.ast.Expression;
	using ExpressionStatement = com.google.minijoe.compiler.ast.ExpressionStatement;
	using ForInStatement = com.google.minijoe.compiler.ast.ForInStatement;
	using ForStatement = com.google.minijoe.compiler.ast.ForStatement;
	using FunctionDeclaration = com.google.minijoe.compiler.ast.FunctionDeclaration;
	using FunctionLiteral = com.google.minijoe.compiler.ast.FunctionLiteral;
	using Identifier = com.google.minijoe.compiler.ast.Identifier;
	using IfStatement = com.google.minijoe.compiler.ast.IfStatement;
	using IncrementExpression = com.google.minijoe.compiler.ast.IncrementExpression;
	using LabelledStatement = com.google.minijoe.compiler.ast.LabelledStatement;
	using LogicalAndExpression = com.google.minijoe.compiler.ast.LogicalAndExpression;
	using LogicalOrExpression = com.google.minijoe.compiler.ast.LogicalOrExpression;
	using NewExpression = com.google.minijoe.compiler.ast.NewExpression;
	using NullLiteral = com.google.minijoe.compiler.ast.NullLiteral;
	using NumberLiteral = com.google.minijoe.compiler.ast.NumberLiteral;
	using ObjectLiteral = com.google.minijoe.compiler.ast.ObjectLiteral;
	using ObjectLiteralProperty = com.google.minijoe.compiler.ast.ObjectLiteralProperty;
	using Program = com.google.minijoe.compiler.ast.Program;
	using PropertyExpression = com.google.minijoe.compiler.ast.PropertyExpression;
	using ReturnStatement = com.google.minijoe.compiler.ast.ReturnStatement;
	using Statement = com.google.minijoe.compiler.ast.Statement;
	using StringLiteral = com.google.minijoe.compiler.ast.StringLiteral;
	using SwitchStatement = com.google.minijoe.compiler.ast.SwitchStatement;
	using ThisLiteral = com.google.minijoe.compiler.ast.ThisLiteral;
	using ThrowStatement = com.google.minijoe.compiler.ast.ThrowStatement;
	using TryStatement = com.google.minijoe.compiler.ast.TryStatement;
	using UnaryOperatorExpression = com.google.minijoe.compiler.ast.UnaryOperatorExpression;
	using VariableDeclaration = com.google.minijoe.compiler.ast.VariableDeclaration;
	using VariableExpression = com.google.minijoe.compiler.ast.VariableExpression;
	using VariableStatement = com.google.minijoe.compiler.ast.VariableStatement;
	using WhileStatement = com.google.minijoe.compiler.ast.WhileStatement;
	using WithStatement = com.google.minijoe.compiler.ast.WithStatement;

	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public class PrintVisitor : Visitor
	{
	  internal int depth = 0;

	  public PrintVisitor()
	  {
	  }

	  //
	  // utilities
	  //

	  public virtual void incrementDepth()
	  {
		depth++;
	  }

	  public virtual void decrementDepth()
	  {
		depth--;
	  }

	  private void write(string @string)
	  {
		for (int i = 0; i < depth; i++)
		{
		  Console.Write("  ");
		}

		Console.WriteLine(@string);
	  }

	  //
	  // nodes
	  //

	  public virtual Program visit(Program node)
	  {
		write("program");

		return node;
	  }

	  //
	  // statements
	  //

	  public virtual Statement visit(FunctionDeclaration declaration)
	  {
		write("function declaration");

		return declaration;
	  }

	  public virtual Statement visit(BlockStatement statement)
	  {
		write("block (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(BreakStatement statement)
	  {
		write("break (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(CaseStatement statement)
	  {
		write("case (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(ContinueStatement statement)
	  {
		write("continue (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(DoStatement statement)
	  {
		write("do (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(EmptyStatement statement)
	  {
		write("empty (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(ExpressionStatement statement)
	  {
		write("expression statement (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(ForStatement statement)
	  {
		write("for (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(ForInStatement statement)
	  {
		write("for in (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(IfStatement statement)
	  {
		write("if (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(LabelledStatement statement)
	  {
		write("label (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(ReturnStatement statement)
	  {
		write("return (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(SwitchStatement statement)
	  {
		write("switch (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(ThrowStatement statement)
	  {
		write("throw (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(TryStatement statement)
	  {
		write("try (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(VariableStatement statement)
	  {
		write("var (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(WhileStatement statement)
	  {
		write("while (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  public virtual Statement visit(WithStatement statement)
	  {
		write("with (line = " + statement.LineNumber + ")");

		return statement;
	  }

	  //
	  // expressions
	  //

	  public virtual Expression visit(AssignmentExpression expression)
	  {
		write("assignment expression");

		return expression;
	  }

	  public virtual Expression visit(AssignmentOperatorExpression expression)
	  {
		write(expression.type.ToString());

		return expression;
	  }

	  public virtual Expression visit(BinaryOperatorExpression expression)
	  {
		write("binary operator " + expression.@operator);

		return expression;
	  }

	  public virtual Expression visit(CallExpression expression)
	  {
		write("call");

		return expression;
	  }

	  public virtual Expression visit(ConditionalExpression expression)
	  {
		write("?");

		return expression;
	  }

	  public virtual Expression visit(DeleteExpression expression)
	  {
		write("delete");

		return expression;
	  }

	  public virtual Expression visit(IncrementExpression expression)
	  {
		write((expression.post ? "postfix " : "prefix ") + expression.value);

		return expression;
	  }

	  public virtual Expression visit(LogicalAndExpression expression)
	  {
		write("&&");

		return expression;
	  }

	  public virtual Expression visit(LogicalOrExpression expression)
	  {
		write("||");

		return expression;
	  }

	  public virtual Expression visit(NewExpression expression)
	  {
		write("new");

		return expression;
	  }

	  public virtual Expression visit(PropertyExpression expression)
	  {
		write("property");

		return expression;
	  }

	  public virtual Expression visit(UnaryOperatorExpression expression)
	  {
		write("unary operator " + expression.@operator);

		return expression;
	  }

	  public virtual Expression visit(VariableExpression expression)
	  {
		write("variable expression");

		return expression;
	  }

	  public virtual Expression visit(VariableDeclaration declaration)
	  {
		write("variable declaration");

		return declaration;
	  }

	  //
	  // literals
	  //

	  public virtual Expression visit(Identifier identifier)
	  {
		write("identifier = \"" + identifier.@string + "\"");

		return identifier;
	  }

	  public virtual Expression visit(ThisLiteral literal)
	  {
		write("this literal");

		return literal;
	  }

	  public virtual Expression visit(NullLiteral literal)
	  {
		write("null literal");

		return literal;
	  }

	  public virtual Expression visit(BooleanLiteral literal)
	  {
		write("boolean literal = " + literal.value);

		return literal;
	  }

	  public virtual Expression visit(NumberLiteral literal)
	  {
		write("numeric literal = " + literal.value);

		return literal;
	  }

	  public virtual Expression visit(StringLiteral literal)
	  {
		write("string literal = \"" + literal.@string + "\"");

		return literal;
	  }

	  public virtual Expression visit(ArrayLiteral literal)
	  {
		write("array literal");

		return literal;
	  }

	  public virtual Expression visit(FunctionLiteral literal)
	  {
		write("function literal");

		return literal;
	  }

	  public virtual Expression visit(ObjectLiteral literal)
	  {
		write("object literal");

		return literal;
	  }

	  public virtual Expression visit(ObjectLiteralProperty property)
	  {
		write("object literal property");

		return property;
	  }
	}

}