// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor.combinator
{

	using Expression = com.google.minijoe.compiler.ast.Expression;
	using Program = com.google.minijoe.compiler.ast.Program;
	using Statement = com.google.minijoe.compiler.ast.Statement;

	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public class DebugVisitor : SequenceVisitor
	{
	  internal class IncrementVisitor : CommonVisitor
	  {
		  private readonly DebugVisitor outerInstance;

		internal PrintVisitor visitor;

		public IncrementVisitor(DebugVisitor outerInstance, PrintVisitor visitor)
		{
			this.outerInstance = outerInstance;
		  this.visitor = visitor;
		}

		public override Program visit(Program program)
		{
		  visitor.incrementDepth();

		  return program;
		}

		public override Statement visit(Statement statement)
		{
		  visitor.incrementDepth();

		  return statement;
		}

		public override Expression visit(Expression expression)
		{
		  visitor.incrementDepth();

		  return expression;
		}
	  }

	  internal class DecrementVisitor : CommonVisitor
	  {
		  private readonly DebugVisitor outerInstance;

		internal PrintVisitor visitor;

		public DecrementVisitor(DebugVisitor outerInstance, PrintVisitor visitor)
		{
			this.outerInstance = outerInstance;
		  this.visitor = visitor;
		}

		public override Program visit(Program program)
		{
		  visitor.decrementDepth();

		  return program;
		}

		public override Statement visit(Statement statement)
		{
		  visitor.decrementDepth();

		  return statement;
		}

		public override Expression visit(Expression expression)
		{
		  visitor.decrementDepth();

		  return expression;
		}
	  }

	  public DebugVisitor()
	  {
//JAVA TO C# CONVERTER WARNING: The original Java variable was marked 'final':
//ORIGINAL LINE: final PrintVisitor visitor = new PrintVisitor();
		PrintVisitor visitor = new PrintVisitor();

		visitors = new Visitor[] {visitor, new IncrementVisitor(this, visitor), new TraversalVisitor(this), new DecrementVisitor(this, visitor)};
	  }
	}

}