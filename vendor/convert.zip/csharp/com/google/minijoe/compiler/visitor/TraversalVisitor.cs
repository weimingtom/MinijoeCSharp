// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor
{

	using ArrayLiteral = com.google.minijoe.compiler.ast.ArrayLiteral;
	using AssignmentExpression = com.google.minijoe.compiler.ast.AssignmentExpression;
	using AssignmentOperatorExpression = com.google.minijoe.compiler.ast.AssignmentOperatorExpression;
	using BinaryExpression = com.google.minijoe.compiler.ast.BinaryExpression;
	using BinaryOperatorExpression = com.google.minijoe.compiler.ast.BinaryOperatorExpression;
	using BlockStatement = com.google.minijoe.compiler.ast.BlockStatement;
	using BooleanLiteral = com.google.minijoe.compiler.ast.BooleanLiteral;
	using BreakStatement = com.google.minijoe.compiler.ast.BreakStatement;
	using CallExpression = com.google.minijoe.compiler.ast.CallExpression;
	using CaseStatement = com.google.minijoe.compiler.ast.CaseStatement;
	using ConditionalExpression = com.google.minijoe.compiler.ast.ConditionalExpression;
	using ContinueStatement = com.google.minijoe.compiler.ast.ContinueStatement;
	using DeleteExpression = com.google.minijoe.compiler.ast.DeleteExpression;
	using DoStatement = com.google.minijoe.compiler.ast.DoStatement;
	using EmptyStatement = com.google.minijoe.compiler.ast.EmptyStatement;
	using Expression = com.google.minijoe.compiler.ast.Expression;
	using ExpressionStatement = com.google.minijoe.compiler.ast.ExpressionStatement;
	using ForInStatement = com.google.minijoe.compiler.ast.ForInStatement;
	using ForStatement = com.google.minijoe.compiler.ast.ForStatement;
	using FunctionDeclaration = com.google.minijoe.compiler.ast.FunctionDeclaration;
	using FunctionLiteral = com.google.minijoe.compiler.ast.FunctionLiteral;
	using Identifier = com.google.minijoe.compiler.ast.Identifier;
	using IfStatement = com.google.minijoe.compiler.ast.IfStatement;
	using IncrementExpression = com.google.minijoe.compiler.ast.IncrementExpression;
	using LabelledStatement = com.google.minijoe.compiler.ast.LabelledStatement;
	using LogicalAndExpression = com.google.minijoe.compiler.ast.LogicalAndExpression;
	using LogicalOrExpression = com.google.minijoe.compiler.ast.LogicalOrExpression;
	using NewExpression = com.google.minijoe.compiler.ast.NewExpression;
	using NullLiteral = com.google.minijoe.compiler.ast.NullLiteral;
	using NumberLiteral = com.google.minijoe.compiler.ast.NumberLiteral;
	using ObjectLiteral = com.google.minijoe.compiler.ast.ObjectLiteral;
	using ObjectLiteralProperty = com.google.minijoe.compiler.ast.ObjectLiteralProperty;
	using Program = com.google.minijoe.compiler.ast.Program;
	using PropertyExpression = com.google.minijoe.compiler.ast.PropertyExpression;
	using ReturnStatement = com.google.minijoe.compiler.ast.ReturnStatement;
	using Statement = com.google.minijoe.compiler.ast.Statement;
	using StringLiteral = com.google.minijoe.compiler.ast.StringLiteral;
	using SwitchStatement = com.google.minijoe.compiler.ast.SwitchStatement;
	using ThisLiteral = com.google.minijoe.compiler.ast.ThisLiteral;
	using ThrowStatement = com.google.minijoe.compiler.ast.ThrowStatement;
	using TryStatement = com.google.minijoe.compiler.ast.TryStatement;
	using UnaryExpression = com.google.minijoe.compiler.ast.UnaryExpression;
	using UnaryOperatorExpression = com.google.minijoe.compiler.ast.UnaryOperatorExpression;
	using VariableDeclaration = com.google.minijoe.compiler.ast.VariableDeclaration;
	using VariableExpression = com.google.minijoe.compiler.ast.VariableExpression;
	using VariableStatement = com.google.minijoe.compiler.ast.VariableStatement;
	using WhileStatement = com.google.minijoe.compiler.ast.WhileStatement;
	using WithStatement = com.google.minijoe.compiler.ast.WithStatement;

	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public class TraversalVisitor : Visitor
	{
	  internal Visitor visitor;

	  public TraversalVisitor()
	  {
	  }

	  public TraversalVisitor(Visitor visitor)
	  {
		this.visitor = visitor;
	  }

	  //
	  // utilities
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: protected com.google.minijoe.compiler.ast.Statement[] visitStatementArray(com.google.minijoe.compiler.ast.Statement[] statements) throws com.google.minijoe.compiler.CompilerException
	  protected internal virtual Statement[] visitStatementArray(Statement[] statements)
	  {
		if (statements != null)
		{
		  for (int i = 0; i < statements.Length; i++)
		  {
			statements[i] = visitStatement(statements[i]);
		  }
		}

		return statements;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: protected com.google.minijoe.compiler.ast.Statement visitStatement(com.google.minijoe.compiler.ast.Statement statement) throws com.google.minijoe.compiler.CompilerException
	  protected internal virtual Statement visitStatement(Statement statement)
	  {
		if (statement != null)
		{
		  statement = statement.visitStatement(visitor);
		}

		return statement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: protected com.google.minijoe.compiler.ast.Expression[] visitExpressionArray(com.google.minijoe.compiler.ast.Expression[] expressions) throws com.google.minijoe.compiler.CompilerException
	  protected internal virtual Expression[] visitExpressionArray(Expression[] expressions)
	  {
		if (expressions != null)
		{
		  for (int i = 0; i < expressions.Length; i++)
		  {
			expressions[i] = visitExpression(expressions[i]);
		  }
		}

		return expressions;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: protected com.google.minijoe.compiler.ast.Expression visitExpression(com.google.minijoe.compiler.ast.Expression expression) throws com.google.minijoe.compiler.CompilerException
	  protected internal virtual Expression visitExpression(Expression expression)
	  {
		if (expression != null)
		{
		  expression = expression.visitExpression(visitor);
		}

		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: protected com.google.minijoe.compiler.ast.Expression visitBinaryExpression(com.google.minijoe.compiler.ast.BinaryExpression expression) throws com.google.minijoe.compiler.CompilerException
	  protected internal virtual Expression visitBinaryExpression(BinaryExpression expression)
	  {
		expression.leftExpression = visitExpression(expression.leftExpression);
		expression.rightExpression = visitExpression(expression.rightExpression);

		return expression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: protected com.google.minijoe.compiler.ast.Expression visitUnaryExpression(com.google.minijoe.compiler.ast.UnaryExpression expression) throws com.google.minijoe.compiler.CompilerException
	  protected internal virtual Expression visitUnaryExpression(UnaryExpression expression)
	  {
		expression.subExpression = visitExpression(expression.subExpression);

		return expression;
	  }


//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: protected com.google.minijoe.compiler.ast.Identifier[] visitIdentifierArray(com.google.minijoe.compiler.ast.Identifier[] identifiers) throws com.google.minijoe.compiler.CompilerException
	  protected internal virtual Identifier[] visitIdentifierArray(Identifier[] identifiers)
	  {
		if (identifiers != null)
		{
		  for (int i = 0; i < identifiers.Length; i++)
		  {
			identifiers[i] = visitIdentifier(identifiers[i]);
		  }
		}

		return identifiers;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: protected com.google.minijoe.compiler.ast.Identifier visitIdentifier(com.google.minijoe.compiler.ast.Identifier identifier) throws com.google.minijoe.compiler.CompilerException
	  protected internal virtual Identifier visitIdentifier(Identifier identifier)
	  {
		if (identifier != null)
		{
		  identifier = (Identifier) identifier.visitExpression(visitor);
		}

		return identifier;
	  }

	  //
	  // nodes
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Program visit(com.google.minijoe.compiler.ast.Program program) throws com.google.minijoe.compiler.CompilerException
	  public virtual Program visit(Program program)
	  {
		program.functions = visitStatementArray(program.functions);
		program.statements = visitStatementArray(program.statements);

		return program;
	  }

	  //
	  // statements
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.FunctionDeclaration functionDeclaration) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(FunctionDeclaration functionDeclaration)
	  {
		functionDeclaration.literal = (FunctionLiteral) visitExpression(functionDeclaration.literal);

		return functionDeclaration;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.BlockStatement blockStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(BlockStatement blockStatement)
	  {
		blockStatement.statements = visitStatementArray(blockStatement.statements);

		return blockStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.BreakStatement breakStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(BreakStatement breakStatement)
	  {
		breakStatement.identifier = visitIdentifier(breakStatement.identifier);

		return breakStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.CaseStatement caseStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(CaseStatement caseStatement)
	  {
		caseStatement.expression = visitExpression(caseStatement.expression);
		caseStatement.statements = visitStatementArray(caseStatement.statements);

		return caseStatement;
	  }


//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ContinueStatement continueStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ContinueStatement continueStatement)
	  {
		continueStatement.identifier = visitIdentifier(continueStatement.identifier);

		return continueStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.DoStatement doStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(DoStatement doStatement)
	  {
		doStatement.statement = visitStatement(doStatement.statement);
		doStatement.expression = visitExpression(doStatement.expression);

		return doStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.EmptyStatement emptyStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(EmptyStatement emptyStatement)
	  {
		return emptyStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ExpressionStatement expressionStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ExpressionStatement expressionStatement)
	  {
		expressionStatement.expression = visitExpression(expressionStatement.expression);

		return expressionStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ForStatement forStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ForStatement forStatement)
	  {
		forStatement.initial = visitExpression(forStatement.initial);
		forStatement.condition = visitExpression(forStatement.condition);
		forStatement.increment = visitExpression(forStatement.increment);
		forStatement.statement = visitStatement(forStatement.statement);

		return forStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ForInStatement forInStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ForInStatement forInStatement)
	  {
		forInStatement.variable = visitExpression(forInStatement.variable);
		forInStatement.expression = visitExpression(forInStatement.expression);
		forInStatement.statement = visitStatement(forInStatement.statement);

		return forInStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.IfStatement ifStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(IfStatement ifStatement)
	  {
		ifStatement.expression = visitExpression(ifStatement.expression);
		ifStatement.trueStatement = visitStatement(ifStatement.trueStatement);
		ifStatement.falseStatement = visitStatement(ifStatement.falseStatement);

		return ifStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.LabelledStatement labelledStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(LabelledStatement labelledStatement)
	  {
		labelledStatement.identifier = visitIdentifier(labelledStatement.identifier);
		labelledStatement.statement = visitStatement(labelledStatement.statement);

		return labelledStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ReturnStatement returnStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ReturnStatement returnStatement)
	  {
		returnStatement.expression = visitExpression(returnStatement.expression);

		return returnStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.SwitchStatement switchStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(SwitchStatement switchStatement)
	  {
		switchStatement.expression = visitExpression(switchStatement.expression);
		switchStatement.clauses = (CaseStatement[]) visitStatementArray(switchStatement.clauses);

		return switchStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ThrowStatement throwStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ThrowStatement throwStatement)
	  {
		throwStatement.expression = visitExpression(throwStatement.expression);

		return throwStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.TryStatement tryStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(TryStatement tryStatement)
	  {
		tryStatement.tryBlock = visitStatement(tryStatement.tryBlock);
		tryStatement.catchIdentifier = visitIdentifier(tryStatement.catchIdentifier);
		tryStatement.catchBlock = visitStatement(tryStatement.catchBlock);
		tryStatement.finallyBlock = visitStatement(tryStatement.finallyBlock);

		return tryStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.VariableStatement variableStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(VariableStatement variableStatement)
	  {
		variableStatement.declarations = (VariableDeclaration[]) visitExpressionArray(variableStatement.declarations);

		return variableStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.WhileStatement whileStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(WhileStatement whileStatement)
	  {
		whileStatement.expression = visitExpression(whileStatement.expression);
		whileStatement.statement = visitStatement(whileStatement.statement);

		return whileStatement;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.WithStatement withStatement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(WithStatement withStatement)
	  {
		withStatement.expression = visitExpression(withStatement.expression);
		withStatement.statement = visitStatement(withStatement.statement);

		return withStatement;
	  }

	  //
	  // Expressions
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.AssignmentExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(AssignmentExpression expression)
	  {
		return visitBinaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.AssignmentOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(AssignmentOperatorExpression expression)
	  {
		return visitBinaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.BinaryOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(BinaryOperatorExpression expression)
	  {
		return visitBinaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.CallExpression callExpression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(CallExpression callExpression)
	  {
		callExpression.function = visitExpression(callExpression.function);
		callExpression.arguments = visitExpressionArray(callExpression.arguments);

		return callExpression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ConditionalExpression conditionalExpression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ConditionalExpression conditionalExpression)
	  {
		conditionalExpression.expression = visitExpression(conditionalExpression.expression);
		conditionalExpression.trueExpression = visitExpression(conditionalExpression.trueExpression);
		conditionalExpression.falseExpression = visitExpression(conditionalExpression.falseExpression);

		return conditionalExpression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.DeleteExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(DeleteExpression expression)
	  {
		return visitUnaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.IncrementExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(IncrementExpression expression)
	  {
		return visitUnaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.LogicalAndExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(LogicalAndExpression expression)
	  {
		return visitBinaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.LogicalOrExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(LogicalOrExpression expression)
	  {
		return visitBinaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NewExpression newExpression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NewExpression newExpression)
	  {
		newExpression.function = visitExpression(newExpression.function);
		newExpression.arguments = visitExpressionArray(newExpression.arguments);

		return newExpression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.PropertyExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(PropertyExpression expression)
	  {
		return visitBinaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.UnaryOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(UnaryOperatorExpression expression)
	  {
		return visitUnaryExpression(expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.VariableExpression variableExpression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(VariableExpression variableExpression)
	  {
		variableExpression.declarations = (VariableDeclaration[]) visitExpressionArray(variableExpression.declarations);

		return variableExpression;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.VariableDeclaration variableDeclaration) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(VariableDeclaration variableDeclaration)
	  {
		variableDeclaration.identifier = visitIdentifier(variableDeclaration.identifier);
		variableDeclaration.initializer = visitExpression(variableDeclaration.initializer);

		return variableDeclaration;
	  }

	  //
	  // literals
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.Identifier identifier) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(Identifier identifier)
	  {
		return identifier;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ThisLiteral thisLiteral) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ThisLiteral thisLiteral)
	  {
		return thisLiteral;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NullLiteral nullLiteral) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NullLiteral nullLiteral)
	  {
		return nullLiteral;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.BooleanLiteral booleanLiteral) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(BooleanLiteral booleanLiteral)
	  {
		return booleanLiteral;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NumberLiteral numberLiteral) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NumberLiteral numberLiteral)
	  {
		return numberLiteral;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.StringLiteral stringLiteral) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(StringLiteral stringLiteral)
	  {
		return stringLiteral;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ArrayLiteral arrayLiteral) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ArrayLiteral arrayLiteral)
	  {
		arrayLiteral.elements = visitExpressionArray(arrayLiteral.elements);

		return arrayLiteral;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.FunctionLiteral functionLiteral) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(FunctionLiteral functionLiteral)
	  {
		functionLiteral.name = visitIdentifier(functionLiteral.name);
		functionLiteral.parameters = visitIdentifierArray(functionLiteral.parameters);
		functionLiteral.variables = visitIdentifierArray(functionLiteral.variables);
		functionLiteral.functions = visitStatementArray(functionLiteral.functions);
		functionLiteral.statements = visitStatementArray(functionLiteral.statements);

		return functionLiteral;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ObjectLiteral objectLiteral) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ObjectLiteral objectLiteral)
	  {
		objectLiteral.properties = (ObjectLiteralProperty[]) visitExpressionArray(objectLiteral.properties);

		return objectLiteral;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ObjectLiteralProperty objectLiteralProperty) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ObjectLiteralProperty objectLiteralProperty)
	  {
		objectLiteralProperty.name = visitExpression(objectLiteralProperty.name);
		objectLiteralProperty.value = visitExpression(objectLiteralProperty.value);

		return objectLiteralProperty;
	  }
	}

}