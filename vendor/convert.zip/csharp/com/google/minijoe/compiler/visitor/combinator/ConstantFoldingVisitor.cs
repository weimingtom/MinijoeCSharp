// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor.combinator
{

	using BinaryOperatorExpression = com.google.minijoe.compiler.ast.BinaryOperatorExpression;
	using Expression = com.google.minijoe.compiler.ast.Expression;
	using NumberLiteral = com.google.minijoe.compiler.ast.NumberLiteral;
	using UnaryOperatorExpression = com.google.minijoe.compiler.ast.UnaryOperatorExpression;

	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public class ConstantFoldingVisitor : IdentityVisitor
	{
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.BinaryOperatorExpression boe) throws com.google.minijoe.compiler.CompilerException
	  public override Expression visit(BinaryOperatorExpression boe)
	  {
		boe.leftExpression = boe.leftExpression.visitExpression(this);
		boe.rightExpression = boe.rightExpression.visitExpression(this);

		if (boe.leftExpression is NumberLiteral && boe.rightExpression is NumberLiteral)
		{
		  double left = ((NumberLiteral) boe.leftExpression).value;
		  double right = ((NumberLiteral) boe.rightExpression).value;

		  Token op = boe.@operator;

		  if (op == Token.OPERATOR_PLUS)
		  {
			return new NumberLiteral(left + right);
		  }
		  else if (op == Token.OPERATOR_MINUS)
		  {
			return new NumberLiteral(left - right);
		  }
		  else if (op == Token.OPERATOR_MULTIPLY)
		  {
			return new NumberLiteral(left * right);
		  }
		  else if (op == Token.OPERATOR_DIVIDE)
		  {
			return new NumberLiteral(left / right);
		  }
		  else if (op == Token.OPERATOR_MODULO)
		  {
			return new NumberLiteral(left % right);
		  }
		}
		return boe;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.UnaryOperatorExpression uoe) throws com.google.minijoe.compiler.CompilerException
	  public override Expression visit(UnaryOperatorExpression uoe)
	  {

		uoe.subExpression = uoe.subExpression.visitExpression(this);

		if (uoe.subExpression is NumberLiteral)
		{
		  double value = ((NumberLiteral) uoe.subExpression).value;
		  Token op = uoe.@operator;

		  if (op == Token.OPERATOR_MINUS)
		  {
			return new NumberLiteral(-value);
		  }
		  else if (op == Token.OPERATOR_PLUS)
		  {
			return new NumberLiteral(value);
		  }
		}
		return uoe;
	  }
	}

}