using System;

// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor.combinator
{

	using Expression = com.google.minijoe.compiler.ast.Expression;
	using FunctionLiteral = com.google.minijoe.compiler.ast.FunctionLiteral;
	using Program = com.google.minijoe.compiler.ast.Program;

	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public class FooVisitor : IdentityVisitor
	{
	  internal class FooTraversal : PostfixVisitor
	  {
		  private readonly FooVisitor outerInstance;

		public FooTraversal(FooVisitor outerInstance, Visitor visitor) : base(visitor)
		{
			this.outerInstance = outerInstance;
		}

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.FunctionLiteral literal) throws com.google.minijoe.compiler.CompilerException
		public virtual Expression visit(FunctionLiteral literal)
		{
		  return literal.visitExpression(new FooVisitor());
		}
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Program visit(com.google.minijoe.compiler.ast.Program program) throws com.google.minijoe.compiler.CompilerException
	  public override Program visit(Program program)
	  {
		Console.WriteLine(this + " visit #1 to  " + program);

		(new TraversalVisitor(new FooTraversal(this, this))).visit(program);

		Console.WriteLine(this + " visit #2 to  " + program);

		return program;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.FunctionLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public override Expression visit(FunctionLiteral literal)
	  {
		Console.WriteLine(this + " visit #1 to " + literal);

		(new TraversalVisitor(new FooTraversal(this, this))).visit(literal);

		Console.WriteLine(this + " visit #2 to " + literal);

		return literal;
	  }
	}

}