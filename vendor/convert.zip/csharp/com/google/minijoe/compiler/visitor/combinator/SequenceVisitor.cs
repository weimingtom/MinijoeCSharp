// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor.combinator
{

	using Expression = com.google.minijoe.compiler.ast.Expression;
	using Program = com.google.minijoe.compiler.ast.Program;
	using Statement = com.google.minijoe.compiler.ast.Statement;

	/// <summary>
	/// Applies a number of visitors, one after the other.
	/// 
	/// @author Andy Hayward
	/// </summary>
	public class SequenceVisitor : CommonVisitor
	{
	  internal Visitor[] visitors;

	  public SequenceVisitor()
	  {
	  }

	  public SequenceVisitor(Visitor[] visitors)
	  {
		this.visitors = visitors;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Program visit(com.google.minijoe.compiler.ast.Program node) throws com.google.minijoe.compiler.CompilerException
	  public override Program visit(Program node)
	  {
		for (int i = 0; i < visitors.Length; i++)
		{
		  node = node.visitProgram(visitors[i]);
		}

		return node;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.Statement node) throws com.google.minijoe.compiler.CompilerException
	  public override Statement visit(Statement node)
	  {
		for (int i = 0; i < visitors.Length; i++)
		{
		  node = node.visitStatement(visitors[i]);
		}

		return node;
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.Expression node) throws com.google.minijoe.compiler.CompilerException
	  public override Expression visit(Expression node)
	  {
		for (int i = 0; i < visitors.Length; i++)
		{
		  node = node.visitExpression(visitors[i]);
		}

		return node;
	  }
	}

}