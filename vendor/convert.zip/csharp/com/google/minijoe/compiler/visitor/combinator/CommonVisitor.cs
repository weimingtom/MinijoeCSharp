// Copyright 2008 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace com.google.minijoe.compiler.visitor.combinator
{

	using ArrayLiteral = com.google.minijoe.compiler.ast.ArrayLiteral;
	using AssignmentExpression = com.google.minijoe.compiler.ast.AssignmentExpression;
	using AssignmentOperatorExpression = com.google.minijoe.compiler.ast.AssignmentOperatorExpression;
	using BinaryOperatorExpression = com.google.minijoe.compiler.ast.BinaryOperatorExpression;
	using BlockStatement = com.google.minijoe.compiler.ast.BlockStatement;
	using BooleanLiteral = com.google.minijoe.compiler.ast.BooleanLiteral;
	using BreakStatement = com.google.minijoe.compiler.ast.BreakStatement;
	using CallExpression = com.google.minijoe.compiler.ast.CallExpression;
	using CaseStatement = com.google.minijoe.compiler.ast.CaseStatement;
	using ConditionalExpression = com.google.minijoe.compiler.ast.ConditionalExpression;
	using ContinueStatement = com.google.minijoe.compiler.ast.ContinueStatement;
	using DeleteExpression = com.google.minijoe.compiler.ast.DeleteExpression;
	using DoStatement = com.google.minijoe.compiler.ast.DoStatement;
	using EmptyStatement = com.google.minijoe.compiler.ast.EmptyStatement;
	using Expression = com.google.minijoe.compiler.ast.Expression;
	using ExpressionStatement = com.google.minijoe.compiler.ast.ExpressionStatement;
	using ForInStatement = com.google.minijoe.compiler.ast.ForInStatement;
	using ForStatement = com.google.minijoe.compiler.ast.ForStatement;
	using FunctionDeclaration = com.google.minijoe.compiler.ast.FunctionDeclaration;
	using FunctionLiteral = com.google.minijoe.compiler.ast.FunctionLiteral;
	using Identifier = com.google.minijoe.compiler.ast.Identifier;
	using IfStatement = com.google.minijoe.compiler.ast.IfStatement;
	using IncrementExpression = com.google.minijoe.compiler.ast.IncrementExpression;
	using LabelledStatement = com.google.minijoe.compiler.ast.LabelledStatement;
	using LogicalAndExpression = com.google.minijoe.compiler.ast.LogicalAndExpression;
	using LogicalOrExpression = com.google.minijoe.compiler.ast.LogicalOrExpression;
	using NewExpression = com.google.minijoe.compiler.ast.NewExpression;
	using NullLiteral = com.google.minijoe.compiler.ast.NullLiteral;
	using NumberLiteral = com.google.minijoe.compiler.ast.NumberLiteral;
	using ObjectLiteral = com.google.minijoe.compiler.ast.ObjectLiteral;
	using ObjectLiteralProperty = com.google.minijoe.compiler.ast.ObjectLiteralProperty;
	using PropertyExpression = com.google.minijoe.compiler.ast.PropertyExpression;
	using ReturnStatement = com.google.minijoe.compiler.ast.ReturnStatement;
	using Statement = com.google.minijoe.compiler.ast.Statement;
	using StringLiteral = com.google.minijoe.compiler.ast.StringLiteral;
	using SwitchStatement = com.google.minijoe.compiler.ast.SwitchStatement;
	using ThisLiteral = com.google.minijoe.compiler.ast.ThisLiteral;
	using ThrowStatement = com.google.minijoe.compiler.ast.ThrowStatement;
	using TryStatement = com.google.minijoe.compiler.ast.TryStatement;
	using UnaryOperatorExpression = com.google.minijoe.compiler.ast.UnaryOperatorExpression;
	using VariableDeclaration = com.google.minijoe.compiler.ast.VariableDeclaration;
	using VariableExpression = com.google.minijoe.compiler.ast.VariableExpression;
	using VariableStatement = com.google.minijoe.compiler.ast.VariableStatement;
	using WhileStatement = com.google.minijoe.compiler.ast.WhileStatement;
	using WithStatement = com.google.minijoe.compiler.ast.WithStatement;

	/// <summary>
	/// @author Andy Hayward
	/// </summary>
	public abstract class CommonVisitor : Visitor
	{
		public abstract com.google.minijoe.compiler.ast.Program visit(com.google.minijoe.compiler.ast.Program program);
	  //
	  // nodes
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public abstract com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.Statement statement) throws com.google.minijoe.compiler.CompilerException;
	  public abstract Statement visit(Statement statement);
//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public abstract com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.Expression expression) throws com.google.minijoe.compiler.CompilerException;
	  public abstract Expression visit(Expression expression);

	  //
	  // statements
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.FunctionDeclaration declaration) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(FunctionDeclaration declaration)
	  {
		return visit((Statement) declaration);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.BlockStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(BlockStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.BreakStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(BreakStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.CaseStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(CaseStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ContinueStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ContinueStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.DoStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(DoStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.EmptyStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(EmptyStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ExpressionStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ExpressionStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ForStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ForStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ForInStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ForInStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.IfStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(IfStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.LabelledStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(LabelledStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ReturnStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ReturnStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.SwitchStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(SwitchStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.ThrowStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(ThrowStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.TryStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(TryStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.VariableStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(VariableStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.WhileStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(WhileStatement statement)
	  {
		return visit((Statement) statement);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Statement visit(com.google.minijoe.compiler.ast.WithStatement statement) throws com.google.minijoe.compiler.CompilerException
	  public virtual Statement visit(WithStatement statement)
	  {
		return visit((Statement) statement);
	  }

	  //
	  // expressions
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.AssignmentExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(AssignmentExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.AssignmentOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(AssignmentOperatorExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.BinaryOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(BinaryOperatorExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.CallExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(CallExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ConditionalExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ConditionalExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.DeleteExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(DeleteExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.LogicalAndExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(LogicalAndExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.LogicalOrExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(LogicalOrExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NewExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NewExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.IncrementExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(IncrementExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.PropertyExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(PropertyExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.UnaryOperatorExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(UnaryOperatorExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.VariableExpression expression) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(VariableExpression expression)
	  {
		return visit((Expression) expression);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.VariableDeclaration declaration) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(VariableDeclaration declaration)
	  {
		return visit((Expression) declaration);
	  }

	  //
	  // literals
	  //

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.Identifier literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(Identifier literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ThisLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ThisLiteral literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NullLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NullLiteral literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.BooleanLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(BooleanLiteral literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.NumberLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(NumberLiteral literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.StringLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(StringLiteral literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ArrayLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ArrayLiteral literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.FunctionLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(FunctionLiteral literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ObjectLiteral literal) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ObjectLiteral literal)
	  {
		return visit((Expression) literal);
	  }

//JAVA TO C# CONVERTER WARNING: Method 'throws' clauses are not available in .NET:
//ORIGINAL LINE: public com.google.minijoe.compiler.ast.Expression visit(com.google.minijoe.compiler.ast.ObjectLiteralProperty property) throws com.google.minijoe.compiler.CompilerException
	  public virtual Expression visit(ObjectLiteralProperty property)
	  {
		return visit((Expression) property);
	  }
	}

}